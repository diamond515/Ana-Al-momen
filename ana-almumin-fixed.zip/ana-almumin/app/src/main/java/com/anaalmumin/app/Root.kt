package com.anaalmumin.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

enum class Tab { QURAN, SEARCH, HOME, AZKAR, STORIES }

private fun tabIcon(tab: Tab): ImageVector = when (tab) {
    Tab.QURAN -> Icons.Filled.MenuBook
    Tab.SEARCH -> Icons.Filled.Search
    Tab.HOME -> Icons.Filled.Home
    Tab.AZKAR -> Icons.Filled.Star
    Tab.STORIES -> Icons.Filled.Book
}

private fun tabLabel(tab: Tab, s: Strings): String = when (tab) {
    Tab.QURAN -> s.tabQuran
    Tab.SEARCH -> s.tabSearch
    Tab.HOME -> s.tabHome
    Tab.AZKAR -> s.tabAzkar
    Tab.STORIES -> s.tabStories
}

// المسارات: main, settings, favorites, downloads, sources, about, readers, reader/<id>, player
@Composable
fun Root(
    prefs: AppPrefs,
    lang: Lang,
    theme: ThemeMode,
    onLang: (Lang) -> Unit,
    onTheme: (ThemeMode) -> Unit,
) {
    val s = LocalStrings.current
    val context = LocalContext.current
    var stackStr by rememberSaveable { mutableStateOf("main") }
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }

    val stack = stackStr.split(";")
    val route = stack.last()
    val push: (String) -> Unit = { stackStr = stackStr + ";" + it }
    val pop: () -> Unit = {
        if (stack.size > 1) stackStr = stack.dropLast(1).joinToString(";")
    }

    // رسائل أخطاء التشغيل.
    val playError = PlayerController.error
    LaunchedEffect(playError) {
        if (playError != null) {
            val msg = if (playError == PlayError.OFFLINE) s.offlineNeeded else s.playFailed
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            PlayerController.error = null
        }
    }

    if (route != "main") {
        BackHandler { pop() }
    }

    when {
        route == "main" -> MainPage(
            prefs = prefs,
            lang = lang,
            tab = tab,
            onTab = { tab = it },
            onNavigate = push,
        )

        route == "readers" -> ReadersScreen(
            onBack = pop,
            onOpenReader = { push("reader/$it") },
            onOpenPlayer = { push("player") },
        )

        route.startsWith("reader/") -> ReaderScreen(
            readerId = route.removePrefix("reader/"),
            onBack = pop,
            onOpenPlayer = { push("player") },
        )

        route == "player" -> PlayerScreen(onBack = pop)

        route == "settings" -> SubScaffold(title = s.settings, onBack = pop) { padding ->
            SettingsContent(
                lang = lang,
                theme = theme,
                onLang = onLang,
                onTheme = onTheme,
                modifier = Modifier.padding(padding),
            )
        }

        else -> {
            val title = when (route) {
                "favorites" -> s.favorites
                "downloads" -> s.downloads
                "sources" -> s.sources
                else -> s.about
            }
            SubScaffold(title = title, onBack = pop) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(title, style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainPage(
    prefs: AppPrefs,
    lang: Lang,
    tab: Tab,
    onTab: (Tab) -> Unit,
    onNavigate: (String) -> Unit,
) {
    val s = LocalStrings.current
    val context = LocalContext.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var lastBack by remember { mutableLongStateOf(0L) }

    // من الرئيسية: ضغطتان خلال ثانيتين للخروج، وبينهما رسالة Toast.
    BackHandler(enabled = tab == Tab.HOME) {
        val now = System.currentTimeMillis()
        if (now - lastBack < 2000L) {
            (context as? Activity)?.finish()
        } else {
            lastBack = now
            Toast.makeText(context, s.exitHint, Toast.LENGTH_SHORT).show()
        }
    }
    // قرار مؤقت: الرجوع من أي تبويب آخر يعيد إلى الرئيسية (غير محسوم في الوثيقة).
    BackHandler(enabled = tab != Tab.HOME) { onTab(Tab.HOME) }
    // القائمة الجانبية المفتوحة تُغلق أولًا.
    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    val drawerEntries = listOf(
        Triple(Icons.Filled.Settings, s.settings, "settings"),
        Triple(Icons.Filled.Favorite, s.favorites, "favorites"),
        Triple(Icons.Filled.Download, s.downloads, "downloads"),
        Triple(Icons.Filled.Description, s.sources, "sources"),
        Triple(Icons.Filled.Info, s.about, "about"),
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(24.dp))
                Text(
                    text = s.appName,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 12.dp),
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                drawerEntries.forEach { (icon, label, target) ->
                    NavigationDrawerItem(
                        label = { Text(label) },
                        icon = { Icon(icon, contentDescription = null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onNavigate(target)
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    )
                }
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                NavigationDrawerItem(
                    label = { Text(s.whatsapp) },
                    icon = { Icon(Icons.Filled.Chat, contentDescription = null) },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        if (Config.WHATSAPP_NUMBER.isNotBlank()) {
                            val uri = Uri.parse("https://wa.me/${Config.WHATSAPP_NUMBER}")
                            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                        }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                )
            }
        },
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text(tabLabel(tab, s)) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = s.menu)
                        }
                    },
                )
            },
            bottomBar = {
                Column {
                    if (PlayerController.reader != null) {
                        MiniPlayer(onOpen = { onNavigate("player") })
                    }
                    NavigationBar {
                        Tab.values().forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { onTab(t) },
                                icon = { Icon(tabIcon(t), contentDescription = null) },
                                label = { Text(tabLabel(t, s)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                ),
                            )
                        }
                    }
                }
            },
        ) { padding ->
            val contentModifier = Modifier
                .fillMaxSize()
                .padding(padding)
            when (tab) {
                Tab.HOME -> HomeScreen(prefs = prefs, lang = lang, modifier = contentModifier)
                Tab.QURAN -> QuranHomeScreen(
                    onListen = { onNavigate("readers") },
                    modifier = contentModifier,
                )
                else -> Box(modifier = contentModifier, contentAlignment = Alignment.Center) {
                    // محتوى بقية التبويبات يُبنى في مراحل لاحقة.
                    Text(tabLabel(tab, s), style = MaterialTheme.typography.headlineSmall)
                }
            }
        }
    }
}

@Composable
fun SettingsContent(
    lang: Lang,
    theme: ThemeMode,
    onLang: (Lang) -> Unit,
    onTheme: (ThemeMode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalStrings.current
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        SectionTitle(s.language)
        OptionRow(s.arabic, lang == Lang.AR) { onLang(Lang.AR) }
        OptionRow(s.english, lang == Lang.EN) { onLang(Lang.EN) }

        Spacer(Modifier.height(24.dp))

        SectionTitle(s.appearance)
        OptionRow(s.themeLight, theme == ThemeMode.LIGHT) { onTheme(ThemeMode.LIGHT) }
        OptionRow(s.themeDark, theme == ThemeMode.DARK) { onTheme(ThemeMode.DARK) }
        OptionRow(s.themeSystem, theme == ThemeMode.SYSTEM) { onTheme(ThemeMode.SYSTEM) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 8.dp),
    )
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, modifier = Modifier.padding(horizontal = 8.dp))
    }
}
