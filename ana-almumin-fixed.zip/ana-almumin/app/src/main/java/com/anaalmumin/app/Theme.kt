package com.anaalmumin.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

object Brand {
    val Emerald = Color(0xFF0B7A5C)
    val DeepEmerald = Color(0xFF064E3B)
    val Gold = Color(0xFFD8B45A)
    val Ivory = Color(0xFFF4F1E8)
    val Red = Color(0xFFB03030)
    val Success = Color(0xFF1A6B43)
}

// الخط العربي: Amiri، والإنجليزي: Inter (الخطان بترخيص SIL OFL).
val AmiriFamily = FontFamily(
    Font(R.font.amiri_regular, FontWeight.Normal),
    Font(R.font.amiri_bold, FontWeight.Bold),
)

val InterFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_bold, FontWeight.Bold),
)

private fun typographyFor(family: FontFamily): Typography {
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = family),
        displayMedium = d.displayMedium.copy(fontFamily = family),
        displaySmall = d.displaySmall.copy(fontFamily = family),
        headlineLarge = d.headlineLarge.copy(fontFamily = family),
        headlineMedium = d.headlineMedium.copy(fontFamily = family),
        headlineSmall = d.headlineSmall.copy(fontFamily = family),
        titleLarge = d.titleLarge.copy(fontFamily = family),
        titleMedium = d.titleMedium.copy(fontFamily = family),
        titleSmall = d.titleSmall.copy(fontFamily = family),
        bodyLarge = d.bodyLarge.copy(fontFamily = family),
        bodyMedium = d.bodyMedium.copy(fontFamily = family),
        bodySmall = d.bodySmall.copy(fontFamily = family),
        labelLarge = d.labelLarge.copy(fontFamily = family),
        labelMedium = d.labelMedium.copy(fontFamily = family),
        labelSmall = d.labelSmall.copy(fontFamily = family),
    )
}

@Composable
fun AppTheme(dark: Boolean, lang: Lang, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = Brand.Emerald,
            onPrimary = Color.White,
            secondary = Brand.Gold,
            onSecondary = Color.Black,
            background = Color(0xFF0A1411),
            onBackground = Brand.Ivory,
            surface = Color(0xFF10201A),
            onSurface = Brand.Ivory,
            primaryContainer = Brand.DeepEmerald,
            onPrimaryContainer = Brand.Ivory,
            error = Brand.Red,
        )
    } else {
        lightColorScheme(
            primary = Brand.Emerald,
            onPrimary = Color.White,
            secondary = Brand.Gold,
            onSecondary = Color(0xFF3A2E0A),
            background = Brand.Ivory,
            onBackground = Color(0xFF1B1B1B),
            surface = Brand.Ivory,
            onSurface = Color(0xFF1B1B1B),
            primaryContainer = Color(0xFFD7EBE3),
            onPrimaryContainer = Brand.DeepEmerald,
            error = Brand.Red,
        )
    }
    val typography = remember(lang) {
        typographyFor(if (lang == Lang.AR) AmiriFamily else InterFamily)
    }
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
