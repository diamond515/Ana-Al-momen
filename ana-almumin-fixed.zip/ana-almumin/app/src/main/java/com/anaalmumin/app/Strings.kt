package com.anaalmumin.app

import androidx.compose.runtime.staticCompositionLocalOf

class Strings(val lang: Lang) {
    private fun t(ar: String, en: String): String = if (lang == Lang.AR) ar else en

    val appName: String get() = "أنا المؤمن"

    val tabQuran: String get() = t("القرآن", "Quran")
    val tabSearch: String get() = t("البحث القرآني", "Quran Search")
    val tabHome: String get() = t("الرئيسية", "Home")
    val tabAzkar: String get() = t("الأذكار", "Adhkar")
    val tabStories: String get() = t("القصص", "Stories")

    val settings: String get() = t("الإعدادات", "Settings")
    val favorites: String get() = t("المفضلة", "Favorites")
    val downloads: String get() = t("التنزيلات", "Downloads")
    val sources: String get() = t("المصادر والتراخيص", "Sources & Licenses")
    val about: String get() = t("عن التطبيق", "About")
    val whatsapp: String get() = t("التواصل عبر واتساب", "Contact via WhatsApp")

    val language: String get() = t("اللغة", "Language")
    val arabic: String get() = "العربية"
    val english: String get() = "English"
    val appearance: String get() = t("المظهر", "Appearance")
    val themeLight: String get() = t("فاتح", "Light")
    val themeDark: String get() = t("داكن", "Dark")
    val themeSystem: String get() = t("حسب الجهاز", "System default")

    val exitHint: String get() = t("أنت على وشك مغادرة التطبيق", "You are about to leave the app")
    val chooseCity: String get() = t("اختيار المدينة", "Choose city")
    val useMyLocation: String get() = t("استخدام موقعي", "Use my location")
    val myLocation: String get() = t("موقعي", "My location")
    val setLocationPrompt: String get() = t("حدد موقعك لعرض مواقيت الصلاة", "Set your location to see prayer times")
    val locationFailed: String get() = t("تعذّر تحديد الموقع", "Couldn't get your location")
    val cancel: String get() = t("إلغاء", "Cancel")
    val change: String get() = t("تغيير", "Change")

    fun prayer(p: Prayer): String = when (p) {
        Prayer.FAJR -> t("الفجر", "Fajr")
        Prayer.SUNRISE -> t("الشروق", "Sunrise")
        Prayer.DHUHR -> t("الظهر", "Dhuhr")
        Prayer.ASR -> t("العصر", "Asr")
        Prayer.MAGHRIB -> t("المغرب", "Maghrib")
        Prayer.ISHA -> t("العشاء", "Isha")
    }

    val quranListen: String get() = t("استماع", "Listen")
    val quranText: String get() = t("قراءة نصية", "Text reading")
    val quranMushaf: String get() = t("قراءة مصحف", "Mushaf reading")
    val readersTitle: String get() = t("القراء", "Reciters")
    val favoritesFilter: String get() = t("المفضلة", "Favorites")
    val play: String get() = t("تشغيل", "Play")
    val playAll: String get() = t("تشغيل الكل", "Play all")
    val noBio: String get() = t("لا تتوفر نبذة", "No biography available")
    val recitations: String get() = t("التلاوات", "Recitations")
    val offlineNeeded: String get() = t("هذه الوظيفة تتطلب اتصالًا بالإنترنت", "This feature requires an internet connection")
    val playFailed: String get() = t("تعذّر تشغيل التلاوة", "Couldn't play the recitation")
    val repeatTitle: String get() = t("التكرار", "Repeat")
    val repeatOff: String get() = t("إيقاف", "Off")
    val repeatSurah: String get() = t("السورة", "Surah")
    val repeatAyah: String get() = t("آية", "Ayah")
    val repeatAyahs: String get() = t("مجموعة آيات", "Group of ayahs")

    val back: String get() = t("رجوع", "Back")
    val menu: String get() = t("القائمة", "Menu")
}

val LocalStrings = staticCompositionLocalOf { Strings(Lang.AR) }
