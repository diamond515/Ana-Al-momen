package com.anaalmumin.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.delay

@Composable
fun App(prefs: AppPrefs) {
    var lang by remember { mutableStateOf(prefs.lang) }
    var theme by remember { mutableStateOf(prefs.theme) }

    val dark = when (theme) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val direction = if (lang == Lang.AR) LayoutDirection.Rtl else LayoutDirection.Ltr

    AppTheme(dark = dark, lang = lang) {
        CompositionLocalProvider(
            LocalLayoutDirection provides direction,
            LocalStrings provides Strings(lang),
        ) {
            var showSplash by rememberSaveable { mutableStateOf(true) }
            if (showSplash) {
                SplashScreen { showSplash = false }
            } else {
                Root(
                    prefs = prefs,
                    lang = lang,
                    theme = theme,
                    onLang = {
                        lang = it
                        prefs.lang = it
                    },
                    onTheme = {
                        theme = it
                        prefs.theme = it
                    },
                )
            }
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        // مدة وحركة الشاشة الافتتاحية مؤجلة حسب الوثيقة؛ هذا ضبط مؤقت.
        delay(1800)
        onDone()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.DeepEmerald),
        contentAlignment = Alignment.Center,
    ) {
        // الشعار المعتمد كما هو، دون تعديل.
        Image(
            painter = painterResource(R.drawable.logo_splash),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
    }
}
