package com.anaalmumin.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

data class Reader(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val riwayaAr: String,
    val riwayaEn: String,
    val baseUrl: String,
    // حسب الوثيقة: لا يظهر إلا القراء والتسجيلات التي تم التحقق من حقوقها.
    val verified: Boolean,
) {
    fun name(lang: Lang): String = if (lang == Lang.AR) nameAr else nameEn
    fun riwaya(lang: Lang): String = if (lang == Lang.AR) riwayaAr else riwayaEn
    fun url(surah: Int): String = baseUrl + String.format(Locale.ROOT, "%03d.mp3", surah)
}

object Readers {
    private val registry: List<Reader> = listOf(
        // قارئ تجريبي بطلبك لاختبار الاستماع. الرابط من خوادم mp3quran.net.
        // تحقق من حقوق الاستخدام قبل أي إصدار عام.
        Reader(
            id = "alafasy",
            nameAr = "مشاري العفاسي",
            nameEn = "Mishary Alafasy",
            riwayaAr = "حفص عن عاصم",
            riwayaEn = "Hafs from Asim",
            baseUrl = "https://server8.mp3quran.net/afs/",
            verified = true,
        ),
    )

    val all: List<Reader> = registry.filter { it.verified }

    fun byId(id: String?): Reader? = if (id == null) null else all.firstOrNull { it.id == id }
}

object Favs {
    private var prefs: AppPrefs? = null
    var readerIds by mutableStateOf(setOf<String>())
        private set

    fun init(p: AppPrefs) {
        prefs = p
        readerIds = p.favReaders
    }

    fun toggleReader(id: String) {
        val next = if (id in readerIds) readerIds - id else readerIds + id
        readerIds = next
        prefs?.favReaders = next
    }
}
