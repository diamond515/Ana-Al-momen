package com.anaalmumin.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

class PdfDoc(private val pfd: ParcelFileDescriptor, private val renderer: PdfRenderer) {
    val pageCount: Int = renderer.pageCount
    private val lock = Mutex()
    private val cache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    suspend fun render(index: Int, widthPx: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "$index@$widthPx"
        val hit = cache.get(key)
        if (hit != null) return@withContext hit
        lock.withLock {
            try {
                val page = renderer.openPage(index)
                val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(AColor.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                cache.put(key, bmp)
                bmp
            } catch (e: Exception) {
                null
            }
        }
    }

    fun close() {
        try {
            renderer.close()
            pfd.close()
        } catch (e: Exception) {
            // تجاهل.
        }
    }

    companion object {
        fun hasBundled(context: Context): Boolean =
            try {
                context.assets.open("mushaf.pdf").close()
                true
            } catch (e: Exception) {
                false
            }

        fun open(context: Context, uri: String?): PdfDoc? {
            try {
                if (uri != null) {
                    val pfd = context.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
                    if (pfd != null) return PdfDoc(pfd, PdfRenderer(pfd))
                }
                if (hasBundled(context)) {
                    val f = File(context.cacheDir, "mushaf.pdf")
                    if (!f.exists() || f.length() == 0L) {
                        context.assets.open("mushaf.pdf").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    }
                    val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                    return PdfDoc(pfd, PdfRenderer(pfd))
                }
            } catch (e: Exception) {
                return null
            }
            return null
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MushafScreen() {
    val s = LocalStrings.current
    val lang = s.lang
    val context = LocalContext.current
    val prefs = LocalPrefs.current
    var version by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    val doc by produceState<PdfDoc?>(null, version) {
        val d = withContext(Dispatchers.IO) { PdfDoc.open(context, prefs?.mushafUri) }
        failed = d == null
        value = d
    }
    val captured = doc
    DisposableEffect(captured) { onDispose { captured?.close() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // قد لا يدعم المزوّد الإذن الدائم.
            }
            prefs?.mushafUri = uri.toString()
            version++
        }
    }

    val d = doc
    if (d == null) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            if (failed) {
                Text(s.mushafHint, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { picker.launch(arrayOf("application/pdf")) },
                    colors = ButtonDefaults.buttonColors(containerColor = Brand.Emerald, contentColor = Color.White),
                ) { Text(s.mushafPick) }
            } else {
                CircularProgressIndicator(color = neonColor())
            }
        }
        return
    }

    val count = d.pageCount
    val pager = rememberPagerState(initialPage = (prefs?.mushafPage ?: 0).coerceIn(0, count - 1)) { count }
    val scope = rememberCoroutineScope()
    var bookmarks by remember { mutableStateOf(prefs?.mushafBookmarks ?: emptySet()) }
    var showList by remember { mutableStateOf(false) }

    LaunchedEffect(pager) {
        snapshotFlow { pager.currentPage }.collect { prefs?.mushafPage = it }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                s.pageWord + " " + localDigits(pager.currentPage + 1, lang) + " / " + localDigits(count, lang),
                modifier = Modifier.weight(1f),
            )
            val marked = (pager.currentPage + 1) in bookmarks
            IconButton(onClick = {
                val p = pager.currentPage + 1
                bookmarks = if (p in bookmarks) bookmarks - p else bookmarks + p
                prefs?.mushafBookmarks = bookmarks
            }) {
                Icon(
                    if (marked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = null,
                    tint = if (marked) neonGold() else MaterialTheme.colorScheme.onSurface,
                )
            }
            IconButton(onClick = { showList = true }) { Icon(Icons.Filled.Bookmarks, contentDescription = s.bookmarks) }
            IconButton(onClick = { picker.launch(arrayOf("application/pdf")) }) { Icon(Icons.Filled.FolderOpen, contentDescription = s.mushafPick) }
        }
        // المصحف يُقلب من اليمين لليسار دائمًا.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val wPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx().toInt() }
                HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { page ->
                    val bmp by produceState<Bitmap?>(null, page, wPx, d) { value = d.render(page, wPx) }
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        val b = bmp
                        if (b != null) {
                            Image(
                                bitmap = b.asImageBitmap(),
                                contentDescription = null,
                                contentScale = ContentScale.FillWidth,
                                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                            )
                        } else {
                            CircularProgressIndicator(Modifier.padding(40.dp), color = neonColor())
                        }
                    }
                }
            }
        }
    }

    if (showList) {
        ModalBottomSheet(onDismissRequest = { showList = false }) {
            Column(Modifier.padding(bottom = 28.dp)) {
                Text(s.bookmarks, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(16.dp))
                if (bookmarks.isEmpty()) {
                    Text(s.noBookmarks, modifier = Modifier.padding(16.dp))
                }
                bookmarks.sorted().forEach { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            showList = false
                            scope.launch { pager.scrollToPage((p - 1).coerceIn(0, count - 1)) }
                        }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Bookmark, contentDescription = null, tint = neonGold())
                        Spacer(Modifier.width(10.dp))
                        Text(s.pageWord + " " + localDigits(p, lang))
                    }
                }
            }
        }
    }
}
