package com.anaalmumin.app

// الواجهة العربية تستخدم الأرقام الهندية، والإنجليزية الأرقام الغربية.
fun localDigits(text: String, lang: Lang): String {
    if (lang != Lang.AR) return text
    val sb = StringBuilder(text.length)
    for (ch in text) {
        if (ch in '0'..'9') sb.append('٠' + (ch - '0')) else sb.append(ch)
    }
    return sb.toString()
}

fun localDigits(n: Int, lang: Lang): String = localDigits(n.toString(), lang)
