package com.anaalmumin.app

import androidx.compose.foundation.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AdhkarRoot() {
    val s = LocalStrings.current
    val context = LocalContext.current
    val top = Nav.stacks.getValue(Tab.AZKAR).lastOrNull()
    if (top == "tasbih") {
        TasbihScreen { Nav.pop() }
        return
    }
    if (top != null && top.startsWith("azkar/")) {
        val id = top.removePrefix("azkar/").toIntOrNull() ?: 1
        AdhkarDetail(id) { Nav.pop() }
        return
    }
    val cats = rememberAsync("adhkar") { Content.adhkar(context) }
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(s.tabAzkar)
        if (cats == null) {
            Loading()
            return@Column
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text(s.searchHint) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        val q = query.trim()
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 170.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (q.isEmpty()) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickCard(s.morning, Icons.Filled.WbSunny, neonGold(), Modifier.weight(1f)) { Nav.push("azkar/1") }
                        QuickCard(s.evening, Icons.Filled.NightsStay, neonColor(), Modifier.weight(1f)) { Nav.push("azkar/1") }
                    }
                }
                item {
                    NeonCard(Modifier.fillMaxWidth(), accent = neonGold(), onClick = { Nav.push("tasbih") }) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.TouchApp, contentDescription = null, tint = neonGold(), modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(s.tasbihTitle, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                }
                item { Text(s.categories, color = neonGold(), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            }
            val list = if (q.isEmpty()) cats else cats.filter { it.title.contains(q) }
            items(list, key = { it.id }) { c ->
                NeonCard(Modifier.fillMaxWidth(), onClick = { Nav.push("azkar/${c.id}") }) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.title, modifier = Modifier.weight(1f), fontSize = 16.sp)
                        Text(localDigits(c.items.size, s.lang), color = neonColor(), fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCard(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    NeonCard(modifier, accent = accent, onClick = onClick) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(34.dp).glow(accent, 12.dp, 0.4f))
            Spacer(Modifier.height(8.dp))
            Text(label, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AdhkarDetail(id: Int, onBack: () -> Unit) {
    val s = LocalStrings.current
    val context = LocalContext.current
    val cats = rememberAsync("adhkar") { Content.adhkar(context) }
    val cat = cats?.firstOrNull { it.id == id }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(cat?.title ?: s.tabAzkar, onBack = onBack)
        if (cat == null) {
            Loading()
            return@Column
        }
        val remaining = remember(id) { mutableStateListOf<Int>().apply { cat.items.forEach { add(it.count.coerceAtLeast(1)) } } }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 170.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (id == 1) {
                item { Text(s.morningEveningNote, fontSize = 13.sp, color = neonGold()) }
            }
            items(cat.items.size) { i ->
                val item = cat.items[i]
                val left = remaining[i]
                val done = left == 0
                NeonCard(
                    Modifier.fillMaxWidth(),
                    accent = if (done) neonGold() else neonColor(),
                    onClick = { if (left > 0) remaining[i] = left - 1 },
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(item.text, fontSize = 20.sp, lineHeight = 36.sp, fontFamily = AmiriFamily)
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.clip(CircleShape).background(neonColor().copy(alpha = 0.16f)).padding(horizontal = 14.dp, vertical = 6.dp),
                            ) {
                                Text(
                                    if (done) "✓" else localDigits(left, s.lang) + " / " + localDigits(item.count, s.lang),
                                    color = if (done) neonGold() else neonColor(),
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { sharePlainText(context, item.text + "\n\n" + s.shareSuffix) }) {
                                Icon(Icons.Filled.Share, contentDescription = s.share, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
