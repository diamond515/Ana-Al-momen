package com.anaalmumin.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun tabIcon(tab: Tab): ImageVector = when (tab) {
    Tab.QURAN -> Icons.Filled.MenuBook
    Tab.SEARCH -> Icons.Filled.Search
    Tab.HOME -> Icons.Filled.Home
    Tab.AZKAR -> Icons.Filled.AutoAwesome
    Tab.STORIES -> Icons.Filled.AutoStories
}

fun tabLabel(tab: Tab, s: Strings): String = when (tab) {
    Tab.QURAN -> s.tabQuran
    Tab.SEARCH -> s.tabSearch
    Tab.HOME -> s.tabHome
    Tab.AZKAR -> s.tabAzkar
    Tab.STORIES -> s.tabStories
}

// الترتيب المعتمد: القرآن، البحث، الرئيسية (الوسط)، الأذكار، القصص.
@Composable
fun NeonBottomBar(selected: Tab, onSelect: (Tab) -> Unit) {
    val s = LocalStrings.current
    val neon = neonColor()
    val bar = MaterialTheme.colorScheme.surface
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .height(86.dp),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .background(bar)
                .drawBorderTop(neon),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tab.values().forEach { t ->
                if (t == Tab.HOME) {
                    Spacer(Modifier.weight(1.3f))
                } else {
                    val sel = t == selected
                    val c = if (sel) neon else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelect(t) }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            tabIcon(t),
                            contentDescription = tabLabel(t, s),
                            tint = c,
                            modifier = Modifier.size(24.dp).let { if (sel) it.glow(neon, 10.dp, 0.35f) else it },
                        )
                        Text(tabLabel(t, s), fontSize = 10.sp, color = c, maxLines = 1, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
        // زر الرئيسية: الأكبر والأوضح، بارز فوق الشريط.
        val homeSel = selected == Tab.HOME
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(70.dp)
                .glow(neon, 22.dp, if (homeSel) 0.6f else 0.3f)
                .shadow(8.dp, CircleShape)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Brand.Emerald, Brand.DeepEmerald)))
                .border(2.dp, Brush.linearGradient(listOf(Brand.NeonGold, neon)), CircleShape)
                .clickable { onSelect(Tab.HOME) },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Home, contentDescription = s.tabHome, tint = Color.White, modifier = Modifier.size(36.dp))
        }
    }
}

private fun Modifier.drawBorderTop(c: Color): Modifier =
    this.drawWithContent {
        drawContent()
        drawLine(
            brush = Brush.horizontalGradient(listOf(Color.Transparent, c.copy(alpha = 0.7f), Color.Transparent)),
            start = Offset(0f, 0f),
            end = Offset(size.width, 0f),
            strokeWidth = 2f,
        )
    }
