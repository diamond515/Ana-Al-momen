package com.anaalmumin.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// توهج دائري ناعم خلف العنصر (تأثير نيون).
fun Modifier.glow(color: Color, radius: Dp = 28.dp, alpha: Float = 0.45f): Modifier =
    this.drawBehind {
        val r = size.minDimension / 2f + radius.toPx()
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(color.copy(alpha = alpha), Color.Transparent),
                center = center,
                radius = r,
            ),
            radius = r,
            center = center,
        )
    }

// حدود متدرجة مضيئة.
fun Modifier.neonBorder(
    shape: Shape,
    color: Color,
    width: Dp = 1.dp,
    alpha: Float = 0.75f,
): Modifier = this.border(
    width = width,
    brush = Brush.linearGradient(listOf(color.copy(alpha = alpha), color.copy(alpha = 0.12f))),
    shape = shape,
)

@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    accent: Color = neonColor(),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    var m = modifier
        .clip(shape)
        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f))
        .neonBorder(shape, accent)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(modifier = m, content = content)
}
