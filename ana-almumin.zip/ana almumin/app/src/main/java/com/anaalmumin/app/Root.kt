package com.anaalmumin.app

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun Root(
    prefs: AppPrefs,
    lang: Lang,
    theme: ThemeMode,
    onLang: (Lang) -> Unit,
    onTheme: (ThemeMode) -> Unit,
) {
    val s = LocalStrings.current
    val context = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var lastBack by remember { mutableLongStateOf(0L) }
    val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    // البداية دائمًا من الرئيسية.
    LaunchedEffect(Unit) {
        Nav.tab = Tab.HOME
        Nav.overlay = null
    }

    BackHandler {
        when {
            PlayerSheet.open -> PlayerSheet.open = false
            drawer.isOpen -> scope.launch { drawer.close() }
            Nav.overlay != null -> Nav.overlay = null
            Nav.pop() -> {}
            Nav.tab != Tab.HOME -> Nav.tab = Tab.HOME
            else -> {
                val t = System.currentTimeMillis()
                if (t - lastBack < 2000L) {
                    (context as? android.app.Activity)?.finish()
                } else {
                    lastBack = t
                    Toast.makeText(context, s.exitHint, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    CompositionLocalProvider(
        LocalPrefs provides prefs,
        LocalOpenDrawer provides { scope.launch { drawer.open() }; Unit },
    ) {
        ModalNavigationDrawer(
            drawerState = drawer,
            drawerContent = {
                ModalDrawerSheet {
                    Spacer(Modifier.height(24.dp))
                    Text(
                        s.appName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = neonGold(),
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                    )
                    DrawerEntry(Icons.Filled.Settings, s.settings) { scope.launch { drawer.close() }; Nav.overlay = "settings" }
                    DrawerEntry(Icons.Filled.Favorite, s.favorites) { scope.launch { drawer.close() }; Nav.overlay = "favorites" }
                    DrawerEntry(Icons.Filled.Download, s.downloads) { scope.launch { drawer.close() }; Nav.overlay = "downloads" }
                    DrawerEntry(Icons.Filled.Description, s.sources) { scope.launch { drawer.close() }; Nav.overlay = "sources" }
                    DrawerEntry(Icons.Filled.Info, s.about) { scope.launch { drawer.close() }; Nav.overlay = "about" }
                    DrawerEntry(Icons.Filled.Chat, s.whatsapp) {
                        scope.launch { drawer.close() }
                        if (Config.WHATSAPP_NUMBER.isNotBlank()) {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${Config.WHATSAPP_NUMBER}")))
                        } else {
                            Toast.makeText(context, s.comingSoon, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            },
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Box(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize()) {
                        Box(Modifier.weight(1f).fillMaxWidth().statusBarsPadding()) {
                            MainContent(prefs, lang, theme, onLang, onTheme)
                        }
                        NeonBottomBar(Nav.tab) {
                            Nav.overlay = null
                            Nav.select(it)
                        }
                    }
                    PlayerLayer(86.dp + navInset)
                }
            }
        }
    }
}

@Composable
private fun DrawerEntry(icon: ImageVector, label: String, onClick: () -> Unit) {
    NavigationDrawerItem(
        icon = { Icon(icon, contentDescription = null, tint = neonColor()) },
        label = { Text(label) },
        selected = false,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp),
    )
}

@Composable
private fun MainContent(prefs: AppPrefs, lang: Lang, theme: ThemeMode, onLang: (Lang) -> Unit, onTheme: (ThemeMode) -> Unit) {
    val s = LocalStrings.current
    val ov = Nav.overlay
    if (ov != null) {
        when (ov) {
            "settings" -> SettingsScreen(lang, theme, onLang, onTheme) { Nav.overlay = null }
            "favorites" -> FavoritesScreen { Nav.overlay = null }
            "downloads" -> InfoScreen(s.downloads, s.comingSoon) { Nav.overlay = null }
            "sources" -> InfoScreen(s.sources, s.sourcesText) { Nav.overlay = null }
            else -> InfoScreen(s.about, s.aboutText) { Nav.overlay = null }
        }
        return
    }
    when (Nav.tab) {
        Tab.QURAN -> QuranRoot()
        Tab.AZKAR -> AdhkarRoot()
        Tab.HOME -> HomeScreen(prefs)
        Tab.SEARCH -> Column(Modifier.fillMaxSize()) {
            ScreenHeader(s.tabSearch)
            CenterMessage(s.comingSoon)
        }
        Tab.STORIES -> Column(Modifier.fillMaxSize()) {
            ScreenHeader(s.tabStories)
            CenterMessage(s.comingSoon)
        }
    }
}

@Composable
private fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, onBack = onBack)
        Text(
            body,
            modifier = Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            lineHeight = 26.sp,
        )
    }
}

@Composable
private fun FavoritesScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val list = Readers.all.filter { it.id in Favs.readerIds }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(s.favorites, onBack = onBack)
        if (list.isEmpty()) {
            CenterMessage(s.noFavReaders)
        } else {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                list.forEach { r ->
                    NeonCard(Modifier.fillMaxWidth(), onClick = { Nav.openReader(r.id) }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            ReaderArt(r, 48.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(r.name(s.lang), fontWeight = FontWeight.Bold)
                                Text(r.style(s.lang), fontSize = 12.sp, color = neonGold())
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(lang: Lang, theme: ThemeMode, onLang: (Lang) -> Unit, onTheme: (ThemeMode) -> Unit, onBack: () -> Unit) {
    val s = LocalStrings.current
    val context = LocalContext.current
    val inApp = remember { ImageStore.fileNames(context) }
    val required = remember { listOf("bg_nabawi", "bg_azhar", "bg_fatah_alalim") + Readers.imageNames() }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(s.settings, onBack = onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            SectionTitle(s.language)
            OptionRow(s.arabic, lang == Lang.AR) { onLang(Lang.AR) }
            OptionRow(s.english, lang == Lang.EN) { onLang(Lang.EN) }
            SectionTitle(s.appearance)
            OptionRow(s.themeSystem, theme == ThemeMode.SYSTEM) { onTheme(ThemeMode.SYSTEM) }
            OptionRow(s.themeLight, theme == ThemeMode.LIGHT) { onTheme(ThemeMode.LIGHT) }
            OptionRow(s.themeDark, theme == ThemeMode.DARK) { onTheme(ThemeMode.DARK) }
            SectionTitle(s.imagesCheck)
            Text(s.imagesHint, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
            Text(
                s.imagesInApp + ": " + localDigits(inApp.size, lang),
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
            required.forEach { n ->
                val ok = ImageStore.has(context, n)
                Row(Modifier.padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (ok) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                        contentDescription = null,
                        tint = if (ok) Brand.NeonGreen else Brand.Red,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(n, fontSize = 13.sp)
                }
            }
            val mushaf = PdfDoc.hasBundled(context) || LocalPrefs.current?.mushafUri != null
            Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (mushaf) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                    contentDescription = null,
                    tint = if (mushaf) Brand.NeonGreen else Brand.Red,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(s.mushafFile, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}
