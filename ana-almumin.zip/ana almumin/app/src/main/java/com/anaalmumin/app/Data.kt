package com.anaalmumin.app

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

data class AdhkarItem(val text: String, val count: Int)

data class AdhkarCategory(val id: Int, val title: String, val items: List<AdhkarItem>)

data class FeedPost(val id: String, val type: String, val text: String, val source: String)

object Content {
    private var quranCache: List<List<String>>? = null
    private var adhkarCache: List<AdhkarCategory>? = null
    private var feedCache: List<FeedPost>? = null

    // نص القرآن: قائمة سور، كل سورة قائمة آياتها (دون البسملة في أول السور).
    @Synchronized
    fun quran(context: Context): List<List<String>> {
        val cached = quranCache
        if (cached != null) return cached
        val arr = JSONArray(AssetStore.readText(context, "quran.json"))
        val out = ArrayList<List<String>>(arr.length())
        for (i in 0 until arr.length()) {
            val s = arr.getJSONArray(i)
            val list = ArrayList<String>(s.length())
            for (j in 0 until s.length()) list.add(s.getString(j))
            out.add(list)
        }
        quranCache = out
        return out
    }

    @Synchronized
    fun adhkar(context: Context): List<AdhkarCategory> {
        val cached = adhkarCache
        if (cached != null) return cached
        val arr = JSONArray(AssetStore.readText(context, "adhkar.json"))
        val out = ArrayList<AdhkarCategory>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val a = o.getJSONArray("a")
            val items = ArrayList<AdhkarItem>(a.length())
            for (j in 0 until a.length()) {
                val pair = a.getJSONArray(j)
                items.add(AdhkarItem(pair.getString(0), pair.getInt(1)))
            }
            out.add(AdhkarCategory(o.getInt("id"), o.getString("t"), items))
        }
        adhkarCache = out
        return out
    }

    @Synchronized
    fun feed(context: Context): List<FeedPost> {
        val cached = feedCache
        if (cached != null) return cached
        val arr = JSONArray(AssetStore.readText(context, "feed.json"))
        val out = ArrayList<FeedPost>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(FeedPost(o.getString("id"), o.getString("t"), o.getString("x"), o.getString("s")))
        }
        feedCache = out
        return out
    }
}

// تحميل بيانات ثقيلة خارج الخيط الرئيسي.
@Composable
fun <T : Any> rememberAsync(key: Any?, loader: () -> T): T? {
    val state: State<T?> = produceState<T?>(null, key) {
        value = withContext(Dispatchers.IO) { loader() }
    }
    return state.value
}
