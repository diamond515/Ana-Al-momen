package com.anaalmumin.app

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// تصميم السبحة مؤقت إلى أن تُعتمد صورة التصميم.
@Composable
fun TasbihScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val prefs = LocalPrefs.current
    val haptic = LocalHapticFeedback.current
    var count by remember { mutableIntStateOf(prefs?.tasbihCount ?: 0) }
    val neon = neonColor()
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ScreenHeader(s.tasbihTitle, onBack = onBack)
        Spacer(Modifier.weight(1f))
        Text(
            localDigits(count, s.lang),
            fontSize = 72.sp,
            fontWeight = FontWeight.Bold,
            color = neonGold(),
        )
        Text(localDigits(count % 33, s.lang) + " / " + localDigits(33, s.lang), color = neon)
        Spacer(Modifier.height(36.dp))
        Box(
            modifier = Modifier
                .size(210.dp)
                .glow(neon, 30.dp, 0.5f)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Brand.Emerald, Brand.DeepEmerald)))
                .border(3.dp, Brush.linearGradient(listOf(Brand.NeonGold, neon)), CircleShape)
                .clickable {
                    count++
                    prefs?.tasbihCount = count
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                },
            contentAlignment = Alignment.Center,
        ) {
            Text(s.tasbihButton, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(36.dp))
        OutlinedButton(onClick = {
            count = 0
            prefs?.tasbihCount = 0
        }) {
            Icon(Icons.Filled.Refresh, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(s.resetButton)
        }
        Spacer(Modifier.weight(1.4f))
    }
}
