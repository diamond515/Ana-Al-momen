package com.anaalmumin.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(prefs: AppPrefs) {
    val s = LocalStrings.current
    val lang = s.lang
    val context = LocalContext.current

    var cityId by remember { mutableStateOf(prefs.cityId) }
    var gpsLat by remember { mutableStateOf(prefs.lat) }
    var gpsLon by remember { mutableStateOf(prefs.lon) }
    var showPicker by remember { mutableStateOf(false) }
    var locFailed by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var liked by remember { mutableStateOf(prefs.likedPosts) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(20_000L)
        }
    }

    val applyGps: (Double, Double) -> Unit = { la, lo ->
        prefs.cityId = null
        prefs.lat = la
        prefs.lon = lo
        cityId = null
        gpsLat = la
        gpsLon = lo
        locFailed = false
    }
    val useGps: () -> Unit = {
        fetchLocation(context, onResult = { la, lo -> applyGps(la, lo) }, onFail = { locFailed = true })
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) useGps() else locFailed = true
    }
    val requestGps: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) useGps() else permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    val city = Cities.byId(cityId)
    val la = gpsLat
    val lo = gpsLon
    val coords: Pair<Double, Double>? = when {
        city != null -> city.lat to city.lon
        la != null && lo != null -> la to lo
        else -> null
    }
    val label = when {
        city != null -> city.name(lang)
        coords != null -> s.myLocation
        else -> ""
    }
    val feed = rememberAsync("feed") { Content.feed(context) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(s.appName)
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 170.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                if (coords == null) {
                    NoLocationCard(locFailed, requestGps) { showPicker = true }
                } else {
                    val snap = remember(coords, now / 20_000L) {
                        PrayerCalc.snapshot(coords.first, coords.second, Date(now))
                    }
                    PrayerCard(snap, label, now, lang) { showPicker = true }
                    if (locFailed) Text(s.locationFailed, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                }
            }
            item { SectionTitle(s.feedTitle) }
            if (feed == null) {
                item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = neonColor()) } }
            } else {
                items(feed, key = { it.id }) { post ->
                    val isLiked = post.id in liked
                    FeedCard(post, isLiked) {
                        liked = if (isLiked) liked - post.id else liked + post.id
                        prefs.likedPosts = liked
                    }
                }
            }
        }
    }

    if (showPicker) {
        CityPicker(
            lang = lang,
            onDismiss = { showPicker = false },
            onGps = {
                showPicker = false
                requestGps()
            },
            onCity = { c ->
                prefs.cityId = c.id
                cityId = c.id
                locFailed = false
                showPicker = false
            },
        )
    }
}

@Composable
private fun FeedCard(post: FeedPost, liked: Boolean, onLike: () -> Unit) {
    val s = LocalStrings.current
    val context = LocalContext.current
    val isHadith = post.type == "hadith"
    val accent = if (isHadith) neonGold() else neonColor()
    NeonCard(Modifier.fillMaxWidth(), accent = accent) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(if (isHadith) Icons.Filled.FormatQuote else Icons.Filled.AutoAwesome, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (isHadith) s.hadithLabel else s.dhikrLabel, fontWeight = FontWeight.Bold)
                    Text(post.source, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(post.text, fontSize = 19.sp, lineHeight = 33.sp, fontFamily = AmiriFamily)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onLike) {
                    Icon(
                        if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = s.like,
                        tint = if (liked) Brand.Red else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                    )
                }
                IconButton(onClick = {
                    sharePlainText(context, post.text + "\n— " + post.source + "\n\n" + s.shareSuffix)
                }) {
                    Icon(Icons.Filled.Share, contentDescription = s.share, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                }
            }
        }
    }
}

@Composable
private fun NoLocationCard(failed: Boolean, onUseLocation: () -> Unit, onChooseCity: () -> Unit) {
    val s = LocalStrings.current
    NeonCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(s.setLocationPrompt, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onUseLocation,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Brand.Emerald, contentColor = Color.White),
            ) { Text(s.useMyLocation) }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onChooseCity, modifier = Modifier.fillMaxWidth()) { Text(s.chooseCity) }
            if (failed) {
                Spacer(Modifier.height(8.dp))
                Text(s.locationFailed, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun PrayerCard(snap: Snapshot, label: String, now: Long, lang: Lang, onChange: () -> Unit) {
    val s = LocalStrings.current
    val locale = if (lang == Lang.AR) Locale("ar") else Locale.ENGLISH
    val timeFmt = remember(locale) { SimpleDateFormat("h:mm", locale) }
    val periodFmt = remember(locale) { SimpleDateFormat("a", locale) }
    val shape = RoundedCornerShape(28.dp)
    val remainMin = ((snap.nextTime.time - now) / 60_000L).coerceAtLeast(0L).toInt()
    val remain = localDigits(String.format(Locale.ROOT, "%d:%02d", remainMin / 60, remainMin % 60), lang)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .glow(neonColor(), 14.dp, 0.18f)
            .clip(shape)
            .neonBorder(shape, neonColor(), 1.5.dp),
    ) {
        CardBackground(snap.current)
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Brand.NeonGold, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(label, color = Color.White, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                TextButton(onClick = onChange) { Text(s.change, color = Brand.NeonGold) }
            }
            // التاريخ الهجري (أم القرى).
            Text(Hijri.format(Date(now), lang), color = Brand.NeonGold, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Text(s.currentPrayer, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
            Text(s.prayer(snap.current), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    timeFmt.format(snap.currentTime) + " " + periodFmt.format(snap.currentTime),
                    color = Color.White, fontSize = 22.sp,
                )
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text(s.nextPrayer + ": " + s.prayer(snap.next), color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    Text(s.inTime(remain), color = Brand.NeonGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth()) {
                snap.today.forEach { (prayer, time) ->
                    val isCurrent = prayer == snap.current
                    val tc = if (isCurrent) Color(0xFF1B1503) else Color.White
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 2.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isCurrent) Brand.NeonGold else Color.White.copy(alpha = 0.08f))
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(s.prayer(prayer), color = tc, fontSize = 11.sp, fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
                        Text(timeFmt.format(time), color = tc, fontSize = 13.sp)
                        Text(periodFmt.format(time), color = tc, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// خلفية البطاقة حسب الصلاة الحالية: bg_nabawi / bg_azhar / bg_fatah_alalim (أي امتداد).
@Composable
private fun BoxScope.CardBackground(prayer: Prayer) {
    val name = when (prayer) {
        Prayer.FAJR, Prayer.SUNRISE -> "bg_nabawi"
        Prayer.DHUHR, Prayer.ASR -> "bg_azhar"
        Prayer.MAGHRIB, Prayer.ISHA -> "bg_fatah_alalim"
    }
    val img = rememberAssetImage(name, 1200)
    Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Brand.Emerald, Brand.DeepEmerald))))
    if (img != null) {
        Image(bitmap = img, contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
    }
    Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.6f)))))
}

@Composable
private fun CityPicker(lang: Lang, onDismiss: () -> Unit, onGps: () -> Unit, onCity: (City) -> Unit) {
    val s = LocalStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.chooseCity) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                item {
                    TextButton(onClick = onGps, modifier = Modifier.fillMaxWidth()) { Text(s.useMyLocation) }
                }
                items(Cities.all) { c ->
                    TextButton(onClick = { onCity(c) }, modifier = Modifier.fillMaxWidth()) { Text(c.name(lang)) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(s.cancel) } },
    )
}
