package com.anaalmumin.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList

enum class Tab { QURAN, SEARCH, HOME, AZKAR, STORIES }

// التنقل: لكل تبويب مكدس شاشات داخلية، والشريط السفلي ظاهر دائمًا.
object Nav {
    val stacks: Map<Tab, SnapshotStateList<String>> =
        Tab.values().associateWith { mutableStateListOf<String>() }

    var tab by mutableStateOf(Tab.HOME)

    // صفحات القائمة الجانبية (الإعدادات...) تظهر مكان محتوى التبويب.
    var overlay by mutableStateOf<String?>(null)

    // قسم القرآن المختار: 0 استماع، 1 قراءة نصية، 2 مصحف.
    var quranSection by mutableIntStateOf(0)

    fun current(): SnapshotStateList<String> = stacks.getValue(tab)

    fun push(route: String) {
        current().add(route)
    }

    fun pop(): Boolean {
        val s = current()
        if (s.isEmpty()) return false
        s.removeAt(s.size - 1)
        return true
    }

    fun select(t: Tab) {
        if (t == tab) stacks.getValue(t).clear() else tab = t
    }

    fun openReader(id: String) {
        overlay = null
        tab = Tab.QURAN
        quranSection = 0
        val s = stacks.getValue(Tab.QURAN)
        s.clear()
        s.add("reader/$id")
    }
}
