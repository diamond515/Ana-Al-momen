package com.anaalmumin.app

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

object PlayerSheet {
    var open by mutableStateOf(false)
}

private fun fmtTime(ms: Int, lang: Lang): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val m = total / 60
    val sec = total % 60
    return localDigits(String.format(java.util.Locale.ROOT, "%d:%02d", m, sec), lang)
}

// طبقة المشغل: شريط مصغر يُسحب للأعلى فيتحول لمشغل كامل، والعكس بالسحب للأسفل.
@Composable
fun PlayerLayer(bottomBarHeight: androidx.compose.ui.unit.Dp) {
    val reader = PlayerController.reader ?: return
    val s = LocalStrings.current
    val context = LocalContext.current
    val err = PlayerController.error
    LaunchedEffect(err) {
        if (err != null) {
            val msg = if (err == PlayError.OFFLINE) s.offlineNeeded else s.playFailed
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            PlayerController.error = null
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val hPx = with(LocalDensity.current) { maxHeight.toPx() }
        val frac = remember { Animatable(0f) }
        val scope = rememberCoroutineScope()
        LaunchedEffect(PlayerSheet.open) {
            frac.animateTo(if (PlayerSheet.open) 1f else 0f, tween(320))
        }
        val dragState = rememberDraggableState { delta ->
            scope.launch { frac.snapTo((frac.value - delta / (hPx * 0.7f)).coerceIn(0f, 1f)) }
        }
        val onStop: (Float) -> Unit = { v ->
            val target = when {
                v < -700f -> true
                v > 700f -> false
                else -> frac.value > 0.5f
            }
            PlayerSheet.open = target
            scope.launch { frac.animateTo(if (target) 1f else 0f, tween(260)) }
        }

        if (frac.value < 0.99f) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = bottomBarHeight + 2.dp, start = 10.dp, end = 10.dp)
                    .graphicsLayer { alpha = (1f - frac.value * 2.5f).coerceIn(0f, 1f) }
                    .draggable(dragState, Orientation.Vertical, onDragStopped = { v -> onStop(v) }),
            ) {
                MiniPlayerBar(reader) { PlayerSheet.open = true }
            }
        }
        if (frac.value > 0.001f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { translationY = (1f - frac.value) * hPx }
                    .background(MaterialTheme.colorScheme.background)
                    .draggable(dragState, Orientation.Vertical, onDragStopped = { v -> onStop(v) }),
            ) {
                FullPlayer(reader) { PlayerSheet.open = false }
            }
        }
    }
}

@Composable
private fun MiniPlayerBar(reader: Reader, onOpen: () -> Unit) {
    val s = LocalStrings.current
    val lang = s.lang
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .neonBorder(shape, neonColor(), alpha = 0.6f)
            .clickable(onClick = onOpen),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ReaderArt(reader, 44.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    SurahNames.name(PlayerController.surah, lang),
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    reader.name(lang),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                )
            }
            IconButton(onClick = { PlayerController.toggle() }) {
                if (PlayerController.isPreparing) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = neonColor())
                } else {
                    Icon(
                        if (PlayerController.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = neonColor(),
                        modifier = Modifier.size(30.dp),
                    )
                }
            }
        }
        LinearProgressIndicator(
            progress = { PlayerController.progress },
            modifier = Modifier.fillMaxWidth().height(2.dp),
            color = neonColor(),
            trackColor = Color.Transparent,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FullPlayer(reader: Reader, onClose: () -> Unit) {
    val s = LocalStrings.current
    val lang = s.lang
    val neon = neonColor()
    var showRepeat by remember { mutableStateOf(false) }
    var seeking by remember { mutableStateOf(false) }
    var seekValue by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Brand.DeepEmerald.copy(alpha = 0.55f), Color.Transparent)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = s.back, modifier = Modifier.size(32.dp))
            }
            Text(
                s.nowPlaying,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            )
            Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.weight(0.6f))
        Box(Modifier.glow(neon, 40.dp, 0.4f)) {
            ReaderArt(reader, 250.dp)
        }
        Spacer(Modifier.height(28.dp))
        Text(
            SurahNames.name(PlayerController.surah, lang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
        Text(
            reader.name(lang) + " • " + reader.style(lang),
            color = neonGold(),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.weight(0.5f))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.fillMaxWidth()) {
                Slider(
                    value = if (seeking) seekValue else PlayerController.progress,
                    onValueChange = {
                        seeking = true
                        seekValue = it
                    },
                    onValueChangeFinished = {
                        PlayerController.seekTo((seekValue * PlayerController.durationMs).toInt())
                        seeking = false
                    },
                    colors = SliderDefaults.colors(thumbColor = neon, activeTrackColor = neon),
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fmtTime(PlayerController.positionMs, lang), fontSize = 12.sp)
                    Text(fmtTime(PlayerController.durationMs, lang), fontSize = 12.sp)
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { showRepeat = true }) {
                    Icon(
                        if (PlayerController.repeat == RepeatMode.OFF) Icons.Filled.Repeat else Icons.Filled.RepeatOne,
                        contentDescription = s.repeatTitle,
                        tint = if (PlayerController.repeat == RepeatMode.OFF) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else neon,
                    )
                }
                IconButton(onClick = { PlayerController.previous() }) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = null, modifier = Modifier.size(38.dp))
                }
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .glow(neon, 18.dp, 0.5f)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Brand.Emerald, Brand.DeepEmerald)))
                        .border(2.dp, neon, CircleShape)
                        .clickable { PlayerController.toggle() },
                    contentAlignment = Alignment.Center,
                ) {
                    if (PlayerController.isPreparing) {
                        CircularProgressIndicator(Modifier.size(30.dp), strokeWidth = 3.dp, color = Color.White)
                    } else {
                        Icon(
                            if (PlayerController.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(42.dp),
                        )
                    }
                }
                IconButton(onClick = { PlayerController.next() }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = null, modifier = Modifier.size(38.dp))
                }
                IconButton(onClick = { Favs.toggleReader(reader.id) }) {
                    val fav = reader.id in Favs.readerIds
                    Icon(
                        if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = null,
                        tint = if (fav) Brand.Red else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    )
                }
            }
        }
        Spacer(Modifier.weight(0.8f))
    }

    if (showRepeat) {
        ModalBottomSheet(onDismissRequest = { showRepeat = false }) {
            Column(Modifier.padding(bottom = 28.dp)) {
                Text(s.repeatTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                RepeatRow(s.repeatOff, PlayerController.repeat == RepeatMode.OFF, true) {
                    PlayerController.changeRepeat(RepeatMode.OFF)
                    showRepeat = false
                }
                RepeatRow(s.repeatSurah, PlayerController.repeat == RepeatMode.SURAH, true) {
                    PlayerController.changeRepeat(RepeatMode.SURAH)
                    showRepeat = false
                }
                RepeatRow(s.repeatAyah + " — " + s.comingSoon, false, false) {}
                RepeatRow(s.repeatAyahs + " — " + s.comingSoon, false, false) {}
            }
        }
    }
}

@Composable
private fun RepeatRow(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            modifier = Modifier.weight(1f),
            color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
        )
        if (selected) Icon(Icons.Filled.Check, contentDescription = null, tint = neonColor())
    }
}
