package com.anaalmumin.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AssetStore {
    fun readText(context: Context, path: String): String =
        context.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
}

// تحميل الصور من مجلد assets/img بالاسم فقط (أي امتداد، وبدون حساسية لحالة الأحرف).
// وإن لم توجد يحاول البحث في موارد drawable.
object ImageStore {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = HashSet<String>()

    fun fileNames(context: Context): List<String> =
        try {
            context.assets.list("img")?.toList() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

    private fun findAsset(context: Context, base: String): String? {
        val lower = base.lowercase()
        for (f in fileNames(context)) {
            val dot = f.lastIndexOf('.')
            val b = if (dot > 0) f.substring(0, dot) else f
            if (b.lowercase() == lower) return "img/$f"
        }
        return null
    }

    private fun resId(context: Context, base: String): Int =
        context.resources.getIdentifier(base.lowercase(), "drawable", context.packageName)

    fun has(context: Context, base: String): Boolean =
        findAsset(context, base) != null || resId(context, base) != 0

    private fun sampleSize(w: Int, h: Int, maxDim: Int): Int {
        var s = 1
        var m = maxOf(w, h)
        while (m / 2 >= maxDim) {
            m /= 2
            s *= 2
        }
        return s
    }

    private fun fromAssets(context: Context, base: String, maxDim: Int): Bitmap? {
        val path = findAsset(context, base) ?: return null
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            context.assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim)
            context.assets.open(path).use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            null
        }
    }

    private fun fromRes(context: Context, base: String, maxDim: Int): Bitmap? {
        val id = resId(context, base)
        if (id == 0) return null
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeResource(context.resources, id, bounds)
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, maxDim)
            BitmapFactory.decodeResource(context.resources, id, opts)
        } catch (e: Exception) {
            null
        }
    }

    fun load(context: Context, base: String, maxDim: Int): Bitmap? {
        val key = "$base@$maxDim"
        val hit = cache.get(key)
        if (hit != null) return hit
        synchronized(missing) {
            if (missing.contains(key)) return null
        }
        val bmp = fromAssets(context, base, maxDim) ?: fromRes(context, base, maxDim)
        if (bmp != null) {
            cache.put(key, bmp)
        } else {
            synchronized(missing) { missing.add(key) }
        }
        return bmp
    }
}

@Composable
fun rememberAssetImage(base: String, maxDim: Int = 1400): ImageBitmap? {
    val context = LocalContext.current
    val state: State<ImageBitmap?> = produceState<ImageBitmap?>(null, base, maxDim) {
        value = withContext(Dispatchers.IO) {
            ImageStore.load(context, base, maxDim)?.asImageBitmap()
        }
    }
    return state.value
}
