package com.anaalmumin.app

import androidx.compose.foundation.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SurahIndex() {
    val s = LocalStrings.current
    val lang = s.lang
    val context = LocalContext.current
    val prefs = LocalPrefs.current
    val quran = rememberAsync("quran") { Content.quran(context) }
    val last = prefs?.lastTextSurah ?: 0
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 170.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (last in 1..114) {
            item {
                NeonCard(Modifier.fillMaxWidth(), accent = neonGold(), onClick = { Nav.push("text/$last") }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Bookmark, contentDescription = null, tint = neonGold())
                        Spacer(Modifier.width(10.dp))
                        Text(s.continueReading + " • " + SurahNames.name(last, lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        items((1..SurahNames.COUNT).toList(), key = { it }) { n ->
            NeonCard(Modifier.fillMaxWidth(), onClick = { Nav.push("text/$n") }) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(neonColor().copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center,
                    ) { Text(localDigits(n, lang), fontSize = 13.sp, color = neonColor()) }
                    Spacer(Modifier.width(12.dp))
                    Text(SurahNames.name(n, lang), modifier = Modifier.weight(1f), fontSize = 17.sp)
                    val q = quran
                    if (q != null && n - 1 < q.size) {
                        Text(s.ayahCount(q[n - 1].size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
            }
        }
    }
}

private const val BASMALA = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"

@Composable
fun SurahTextScreen(n: Int, onBack: () -> Unit) {
    val s = LocalStrings.current
    val lang = s.lang
    val context = LocalContext.current
    val prefs = LocalPrefs.current
    val quran = rememberAsync("quran") { Content.quran(context) }
    var size by remember { mutableIntStateOf(prefs?.textSize ?: 26) }
    val startScroll = remember(n) { if (prefs != null && prefs.lastTextSurah == n) prefs.lastTextScroll else 0 }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = startScroll)

    LaunchedEffect(n) { prefs?.lastTextSurah = n }
    LaunchedEffect(state, n) {
        snapshotFlow { state.firstVisibleItemIndex }.collect { idx ->
            prefs?.lastTextSurah = n
            prefs?.lastTextScroll = idx
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(SurahNames.name(n, lang), onBack = onBack) {
            IconButton(onClick = {
                size = (size - 2).coerceAtLeast(18)
                prefs?.textSize = size
            }) { Icon(Icons.Filled.Remove, contentDescription = null) }
            IconButton(onClick = {
                size = (size + 2).coerceAtMost(44)
                prefs?.textSize = size
            }) { Icon(Icons.Filled.Add, contentDescription = null) }
        }
        val q = quran
        if (q == null) {
            Loading()
        } else {
            val ayahs = q.getOrNull(n - 1) ?: emptyList()
            LazyColumn(
                state = state,
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 170.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // الفاتحة: البسملة آية منها وهي في النص. التوبة: بلا بسملة.
                if (n != 1 && n != 9) {
                    item {
                        Text(
                            BASMALA,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center,
                            fontSize = (size + 2).sp,
                            color = neonGold(),
                            lineHeight = ((size + 2) * 1.8f).sp,
                        )
                    }
                }
                items(ayahs.size) { i ->
                    val num = localDigits(i + 1, Lang.AR)
                    Text(
                        ayahs[i] + " ﴿" + num + "﴾",
                        modifier = Modifier.fillMaxWidth(),
                        fontSize = size.sp,
                        lineHeight = (size * 1.9f).sp,
                        textAlign = TextAlign.Justify,
                        fontFamily = AmiriFamily,
                    )
                }
            }
        }
    }
}
