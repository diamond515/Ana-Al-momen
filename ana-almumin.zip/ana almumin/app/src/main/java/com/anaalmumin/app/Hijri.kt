package com.anaalmumin.app

import android.icu.util.Calendar
import android.icu.util.IslamicCalendar
import java.util.Date

object Hijri {
    private val monthsAr = listOf(
        "المحرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة",
    )
    private val monthsEn = listOf(
        "Muharram", "Safar", "Rabi' al-awwal", "Rabi' al-thani", "Jumada al-ula", "Jumada al-akhira",
        "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah",
    )

    // التقويم المعتمد: أم القرى. قد يختلف يومًا عن إعلان دار الإفتاء.
    fun format(date: Date, lang: Lang): String {
        val cal = IslamicCalendar()
        cal.setCalculationType(IslamicCalendar.CalculationType.ISLAMIC_UMALQURA)
        cal.time = date
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = cal.get(Calendar.MONTH)
        val year = cal.get(Calendar.YEAR)
        val names = if (lang == Lang.AR) monthsAr else monthsEn
        val name = names.getOrElse(month) { "" }
        return if (lang == Lang.AR) {
            localDigits("$day $name $year", lang) + " هـ"
        } else {
            "$day $name $year AH"
        }
    }
}
