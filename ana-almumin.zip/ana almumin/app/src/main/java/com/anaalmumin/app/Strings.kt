package com.anaalmumin.app

import androidx.compose.runtime.staticCompositionLocalOf

class Strings(val lang: Lang) {
    private fun t(ar: String, en: String): String = if (lang == Lang.AR) ar else en

    val appName: String get() = "أنا المؤمن"

    // التبويبات
    val tabQuran: String get() = t("القرآن", "Quran")
    val tabSearch: String get() = t("البحث القرآني", "Quran Search")
    val tabHome: String get() = t("الرئيسية", "Home")
    val tabAzkar: String get() = t("الأذكار", "Adhkar")
    val tabStories: String get() = t("القصص", "Stories")

    // القائمة الجانبية
    val settings: String get() = t("الإعدادات", "Settings")
    val favorites: String get() = t("المفضلة", "Favorites")
    val downloads: String get() = t("التنزيلات", "Downloads")
    val sources: String get() = t("المصادر والتراخيص", "Sources & Licenses")
    val about: String get() = t("عن التطبيق", "About")
    val whatsapp: String get() = t("التواصل عبر واتساب", "Contact via WhatsApp")
    val menu: String get() = t("القائمة", "Menu")
    val back: String get() = t("رجوع", "Back")
    val comingSoon: String get() = t("قريبًا", "Coming soon")
    val exitHint: String get() = t("أنت على وشك مغادرة التطبيق", "You are about to leave the app")

    // الإعدادات
    val language: String get() = t("اللغة", "Language")
    val arabic: String get() = "العربية"
    val english: String get() = "English"
    val appearance: String get() = t("المظهر", "Appearance")
    val themeLight: String get() = t("فاتح", "Light")
    val themeDark: String get() = t("داكن", "Dark")
    val themeSystem: String get() = t("حسب الجهاز", "System default")
    val imagesCheck: String get() = t("فحص الصور", "Images check")
    val imagesHint: String get() = t(
        "ضع الصور بهذه الأسماء (أي امتداد) في أي مكان داخل المستودع، وسيجمعها البناء تلقائيًا.",
        "Put images with these names (any extension) anywhere in the repo; the build collects them.",
    )
    val imagesInApp: String get() = t("عدد الصور داخل التطبيق", "Images inside the app")
    val mushafFile: String get() = t("ملف المصحف mushaf.pdf", "Mushaf file mushaf.pdf")

    // المواقيت
    fun prayer(p: Prayer): String = when (p) {
        Prayer.FAJR -> t("الفجر", "Fajr")
        Prayer.SUNRISE -> t("الشروق", "Sunrise")
        Prayer.DHUHR -> t("الظهر", "Dhuhr")
        Prayer.ASR -> t("العصر", "Asr")
        Prayer.MAGHRIB -> t("المغرب", "Maghrib")
        Prayer.ISHA -> t("العشاء", "Isha")
    }

    val chooseCity: String get() = t("اختيار المدينة", "Choose city")
    val useMyLocation: String get() = t("استخدام موقعي", "Use my location")
    val myLocation: String get() = t("موقعي", "My location")
    val setLocationPrompt: String get() = t("حدد موقعك لعرض مواقيت الصلاة", "Set your location to see prayer times")
    val locationFailed: String get() = t("تعذّر تحديد الموقع", "Couldn't get your location")
    val cancel: String get() = t("إلغاء", "Cancel")
    val change: String get() = t("تغيير", "Change")
    val currentPrayer: String get() = t("الصلاة الحالية", "Current prayer")
    val nextPrayer: String get() = t("القادمة", "Next")
    fun inTime(hhmm: String): String = t("بعد $hhmm", "in $hhmm")

    // القرآن
    val quranListen: String get() = t("استماع", "Listen")
    val quranText: String get() = t("قراءة نصية", "Text")
    val quranMushaf: String get() = t("المصحف", "Mushaf")
    val readersTitle: String get() = t("القراء", "Reciters")
    val favoritesFilter: String get() = t("المفضلة", "Favorites")
    val play: String get() = t("تشغيل", "Play")
    val playAll: String get() = t("تشغيل الكل", "Play all")
    val noBio: String get() = t("لا تتوفر نبذة", "No biography available")
    val recitations: String get() = t("التلاوات", "Recitations")
    val offlineNeeded: String get() = t("هذه الوظيفة تتطلب اتصالًا بالإنترنت", "This feature requires an internet connection")
    val playFailed: String get() = t("تعذّر تشغيل التلاوة", "Couldn't play the recitation")
    val nowPlaying: String get() = t("يتم التشغيل الآن", "Now playing")
    val repeatTitle: String get() = t("التكرار", "Repeat")
    val repeatOff: String get() = t("إيقاف", "Off")
    val repeatSurah: String get() = t("السورة", "Surah")
    val repeatAyah: String get() = t("آية", "Ayah")
    val repeatAyahs: String get() = t("مجموعة آيات", "Group of ayahs")
    val noFavReaders: String get() = t("لا يوجد قراء في المفضلة", "No favorite reciters yet")
    fun ayahCount(n: Int): String = t("${localDigits(n, Lang.AR)} آية", "$n verses")
    val continueReading: String get() = t("متابعة القراءة", "Continue reading")

    // المصحف
    val mushafPick: String get() = t("اختيار ملف المصحف PDF", "Choose the Mushaf PDF")
    val mushafHint: String get() = t(
        "لم يتم العثور على ملف المصحف. اختر ملف PDF من جهازك، أو ضع الملف باسم mushaf.pdf داخل المستودع.",
        "No Mushaf file found. Pick a PDF from your device, or add a file named mushaf.pdf to the repo.",
    )
    val mushafOpenFail: String get() = t("تعذّر فتح الملف", "Couldn't open the file")
    val pageWord: String get() = t("صفحة", "Page")
    val bookmarks: String get() = t("العلامات", "Bookmarks")
    val noBookmarks: String get() = t("لا توجد علامات بعد", "No bookmarks yet")

    // الأذكار
    val categories: String get() = t("الأقسام", "Categories")
    val allAdhkar: String get() = t("كل الأذكار", "All adhkar")
    val searchHint: String get() = t("ابحث في الأذكار", "Search adhkar")
    val morning: String get() = t("أذكار الصباح", "Morning adhkar")
    val evening: String get() = t("أذكار المساء", "Evening adhkar")
    val morningEveningNote: String get() = t(
        "تشمل القائمة صيغتي الصباح والمساء كما وردتا؛ اقرأ ما يناسب وقتك.",
        "This list contains both the morning and evening wordings; read what fits your time.",
    )
    val tasbihTitle: String get() = t("السبحة الإلكترونية", "Digital tasbih")
    val tasbihButton: String get() = t("تسبيح", "Tasbih")
    val resetButton: String get() = t("تصفير", "Reset")
    val reset: String get() = t("إعادة", "Reset")

    // الرئيسية
    val feedTitle: String get() = t("من الأحاديث والأذكار", "Hadith & Adhkar")
    val hadithLabel: String get() = t("حديث شريف", "Hadith")
    val dhikrLabel: String get() = t("ذكر", "Dhikr")
    val share: String get() = t("مشاركة", "Share")
    val like: String get() = t("إعجاب", "Like")
    val shareSuffix: String get() = t("تطبيق أنا المؤمن", "Ana Al-Mumin app")

    // صفحات نصية
    val aboutText: String get() = t(
        "أنا المؤمن: تطبيق إسلامي غير ربحي يعمل دون حساب أو تسجيل دخول.",
        "Ana Al-Mumin: a non-profit Islamic app that works without an account.",
    )
    val sourcesText: String get() = t(
        "نص القرآن: Tanzil (النسخة المبسطة) بترخيص CC BY 3.0، ويُعرض دون تعديل في النص؛ وصلتنا البيانات عبر مستودع fawazahmed0/quran-api.\n\n" +
            "الأذكار: حصن المسلم، عبر مستودع rn0x/Adhkar-json.\n\n" +
            "الأحاديث المعروضة في الرئيسية: مختارات من الصحيحين والسنن مع عزو كل حديث لمصدره، وتحتاج مراجعة قبل النشر.\n\n" +
            "التلاوات: روابط من خوادم mp3quran.net، وتخضع حقوقها للتحقق قبل أي إصدار عام.\n\n" +
            "الخطوط: Amiri وInter بترخيص SIL OFL.\n\n" +
            "المصحف: ملف PDF يضعه صاحب التطبيق بعد التحقق من حقوقه.\n\n" +
            "الصور: تخضع للتحقق من الترخيص قبل الاستخدام.",
        "Quran text: Tanzil (simple), CC BY 3.0, shown unmodified; delivered via the fawazahmed0/quran-api repository.\n\n" +
            "Adhkar: Hisn al-Muslim via the rn0x/Adhkar-json repository.\n\n" +
            "Home feed hadith: selections from the Sahihayn and Sunan with sources; review before release.\n\n" +
            "Recitations: links to mp3quran.net servers; rights must be verified before public release.\n\n" +
            "Fonts: Amiri and Inter under SIL OFL.\n\n" +
            "Mushaf: a PDF supplied by the app owner after verifying its rights.\n\n" +
            "Images: license must be verified before use.",
    )
}

val LocalStrings = staticCompositionLocalOf { Strings(Lang.AR) }
