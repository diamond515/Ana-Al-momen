package com.anaalmumin.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

data class Reader(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val styleAr: String,
    val styleEn: String,
    val baseUrl: String,
    // اسم صورة القارئ: reader_<imageId> داخل مجلد الصور.
    val imageId: String = id,
    // حسب الوثيقة: لا يظهر إلا القراء والتسجيلات التي تم التحقق من حقوقها.
    val verified: Boolean = true,
) {
    val riwayaAr: String get() = "حفص عن عاصم"
    val riwayaEn: String get() = "Hafs from Asim"

    fun name(lang: Lang): String = if (lang == Lang.AR) nameAr else nameEn
    fun riwaya(lang: Lang): String = if (lang == Lang.AR) riwayaAr else riwayaEn
    fun style(lang: Lang): String = if (lang == Lang.AR) styleAr else styleEn
    fun url(surah: Int): String = baseUrl + String.format(Locale.ROOT, "%03d.mp3", surah)
}

object Readers {
    private const val M = "https://server"

    // الروابط من خوادم mp3quran.net، وتحتاج اختبارًا على جهازك. للتعديل غيّر baseUrl فقط.
    // تحقق من حقوق الاستخدام قبل أي إصدار عام.
    private val registry: List<Reader> = listOf(
        Reader("alafasy", "مشاري العفاسي", "Mishary Alafasy", "ترتيل", "Murattal", "${M}8.mp3quran.net/afs/"),
        Reader("basit", "عبد الباسط عبد الصمد", "Abdul Basit Abdus-Samad", "ترتيل", "Murattal", "${M}7.mp3quran.net/basit/"),
        Reader("basit_mujawwad", "عبد الباسط عبد الصمد", "Abdul Basit Abdus-Samad", "تجويد", "Mujawwad", "${M}7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/", "basit"),
        Reader("husary", "محمود خليل الحصري", "Mahmoud Khalil Al-Husary", "ترتيل", "Murattal", "${M}13.mp3quran.net/husr/"),
        Reader("husary_mujawwad", "محمود خليل الحصري", "Mahmoud Khalil Al-Husary", "تجويد", "Mujawwad", "${M}13.mp3quran.net/husr/Almusshaf-Al-Mojawwad/", "husary"),
        Reader("minshawi", "محمد صديق المنشاوي", "Mohamed Siddiq Al-Minshawi", "ترتيل", "Murattal", "${M}10.mp3quran.net/minsh/"),
        Reader("minshawi_mujawwad", "محمد صديق المنشاوي", "Mohamed Siddiq Al-Minshawi", "تجويد", "Mujawwad", "${M}10.mp3quran.net/minsh/Almusshaf-Al-Mojawwad/", "minshawi"),
        Reader("maher", "ماهر المعيقلي", "Maher Al-Muaiqly", "ترتيل", "Murattal", "${M}12.mp3quran.net/maher/"),
        Reader("ghamdi", "سعد الغامدي", "Saad Al-Ghamdi", "ترتيل", "Murattal", "${M}7.mp3quran.net/s_gmd/"),
        Reader("sudais", "عبد الرحمن السديس", "Abdulrahman Al-Sudais", "ترتيل", "Murattal", "${M}11.mp3quran.net/sds/"),
        Reader("shuraim", "سعود الشريم", "Saud Al-Shuraim", "ترتيل", "Murattal", "${M}7.mp3quran.net/shur/"),
        Reader("qatami", "ناصر القطامي", "Nasser Al-Qatami", "ترتيل", "Murattal", "${M}6.mp3quran.net/qtm/"),
        Reader("dosari", "ياسر الدوسري", "Yasser Al-Dosari", "ترتيل", "Murattal", "${M}11.mp3quran.net/yasser/"),
        Reader("ajmi", "أحمد العجمي", "Ahmad Al-Ajmi", "ترتيل", "Murattal", "${M}10.mp3quran.net/ajm/"),
        Reader("rifai", "هاني الرفاعي", "Hani Ar-Rifai", "ترتيل", "Murattal", "${M}8.mp3quran.net/hani/"),
        Reader("abkar", "إدريس أبكر", "Idris Abkar", "ترتيل", "Murattal", "${M}6.mp3quran.net/abkr/"),
        Reader("fares", "فارس عباد", "Fares Abbad", "ترتيل", "Murattal", "${M}8.mp3quran.net/frs_a/"),
        Reader("ali_jaber", "علي جابر", "Ali Jaber", "ترتيل", "Murattal", "${M}11.mp3quran.net/a_jbr/"),
        Reader("ayyub", "محمد أيوب", "Muhammad Ayyub", "ترتيل", "Murattal", "${M}8.mp3quran.net/ayyub/"),
        Reader("shatri", "أبو بكر الشاطري", "Abu Bakr Al-Shatri", "ترتيل", "Murattal", "${M}11.mp3quran.net/shatri/"),
    )

    val all: List<Reader> = registry.filter { it.verified }

    fun byId(id: String?): Reader? = if (id == null) null else all.firstOrNull { it.id == id }

    // أسماء الصور المطلوبة (بدون امتداد).
    fun imageNames(): List<String> = all.map { "reader_" + it.imageId }.distinct()
}

object Favs {
    private var prefs: AppPrefs? = null
    var readerIds by mutableStateOf(setOf<String>())
        private set

    fun init(p: AppPrefs) {
        prefs = p
        readerIds = p.favReaders
    }

    fun toggleReader(id: String) {
        val next = if (id in readerIds) readerIds - id else readerIds + id
        readerIds = next
        prefs?.favReaders = next
    }
}
