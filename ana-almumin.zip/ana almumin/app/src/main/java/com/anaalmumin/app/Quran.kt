package com.anaalmumin.app

import androidx.compose.foundation.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// صفحة القرآن الرئيسية: لا يوجد زر رجوع، والتنقل بين الأقسام بالتبويبات العلوية.
@Composable
fun QuranRoot() {
    val s = LocalStrings.current
    val stack = Nav.stacks.getValue(Tab.QURAN)
    val top = stack.lastOrNull()
    if (top != null && top.startsWith("reader/")) {
        val r = Readers.byId(top.removePrefix("reader/"))
        if (r != null) {
            ReaderScreen(r) { Nav.pop() }
            return
        }
    }
    if (top != null && top.startsWith("text/")) {
        val n = top.removePrefix("text/").toIntOrNull() ?: 1
        SurahTextScreen(n) { Nav.pop() }
        return
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(s.tabQuran)
        SegmentedTabs(
            listOf(s.quranListen, s.quranText, s.quranMushaf),
            Nav.quranSection,
        ) { Nav.quranSection = it }
        Spacer(Modifier.height(6.dp))
        when (Nav.quranSection) {
            0 -> ReadersList()
            1 -> SurahIndex()
            else -> MushafScreen()
        }
    }
}

@Composable
private fun ReadersList() {
    val s = LocalStrings.current
    var onlyFav by remember { mutableStateOf(false) }
    val list = if (onlyFav) Readers.all.filter { it.id in Favs.readerIds } else Readers.all
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = onlyFav,
                onClick = { onlyFav = !onlyFav },
                label = { Text(s.favoritesFilter) },
                leadingIcon = { Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.size(16.dp)) },
            )
        }
        if (list.isEmpty()) {
            CenterMessage(s.noFavReaders)
        } else {
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 170.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list, key = { it.id }) { r -> ReaderRow(r) }
            }
        }
    }
}

@Composable
private fun ReaderRow(r: Reader) {
    val s = LocalStrings.current
    val lang = s.lang
    NeonCard(modifier = Modifier.fillMaxWidth(), onClick = { Nav.push("reader/${r.id}") }) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            ReaderArt(r, 58.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name(lang), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(r.riwaya(lang) + " • " + r.style(lang), fontSize = 12.sp, color = neonGold())
            }
            IconButton(onClick = { Favs.toggleReader(r.id) }) {
                val fav = r.id in Favs.readerIds
                Icon(
                    if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = null,
                    tint = if (fav) Brand.Red else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                )
            }
        }
    }
}

@Composable
fun ReaderScreen(r: Reader, onBack: () -> Unit) {
    val s = LocalStrings.current
    val lang = s.lang
    val all = remember { (1..SurahNames.COUNT).toList() }
    val last = PlayerController.lastSurahFor(r)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(r.name(lang), onBack = onBack)
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 170.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.glow(neonColor(), 30.dp, 0.35f)) { ReaderArt(r, 140.dp) }
                    Spacer(Modifier.height(10.dp))
                    Text(r.riwaya(lang) + " • " + r.style(lang), color = neonGold())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { PlayerController.play(r, last, all) },
                        colors = ButtonDefaults.buttonColors(containerColor = Brand.Emerald, contentColor = Color.White),
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(s.play + " • " + SurahNames.name(last, lang))
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            items(all, key = { it }) { n ->
                val playing = PlayerController.reader?.id == r.id && PlayerController.surah == n
                NeonCard(
                    modifier = Modifier.fillMaxWidth(),
                    accent = if (playing) neonGold() else neonColor(),
                    onClick = { PlayerController.play(r, n, all) },
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(neonColor().copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center,
                        ) { Text(localDigits(n, lang), fontSize = 13.sp, color = neonColor()) }
                        Spacer(Modifier.width(12.dp))
                        Text(SurahNames.name(n, lang), modifier = Modifier.weight(1f), fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal, fontSize = 17.sp)
                        if (playing) Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = neonGold())
                    }
                }
            }
        }
    }
}
