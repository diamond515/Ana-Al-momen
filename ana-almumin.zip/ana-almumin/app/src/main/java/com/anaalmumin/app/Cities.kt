package com.anaalmumin.app

data class City(
    val id: String,
    val ar: String,
    val en: String,
    val lat: Double,
    val lon: Double,
) {
    fun name(lang: Lang): String = if (lang == Lang.AR) ar else en
}

object Cities {
    // قائمة مبدئية؛ أضف مدنًا حسب الحاجة.
    val all: List<City> = listOf(
        City("cairo", "القاهرة", "Cairo", 30.0444, 31.2357),
        City("giza", "الجيزة", "Giza", 30.0131, 31.2089),
        City("alexandria", "الإسكندرية", "Alexandria", 31.2001, 29.9187),
        City("port_said", "بورسعيد", "Port Said", 31.2653, 32.3019),
        City("suez", "السويس", "Suez", 29.9668, 32.5498),
        City("ismailia", "الإسماعيلية", "Ismailia", 30.5965, 32.2715),
        City("mansoura", "المنصورة", "Mansoura", 31.0409, 31.3785),
        City("tanta", "طنطا", "Tanta", 30.7865, 31.0004),
        City("zagazig", "الزقازيق", "Zagazig", 30.5877, 31.5020),
        City("damanhur", "دمنهور", "Damanhur", 31.0341, 30.4682),
        City("fayoum", "الفيوم", "Fayoum", 29.3084, 30.8428),
        City("minya", "المنيا", "Minya", 28.1099, 30.7503),
        City("asyut", "أسيوط", "Asyut", 27.1783, 31.1859),
        City("sohag", "سوهاج", "Sohag", 26.5591, 31.6948),
        City("qena", "قنا", "Qena", 26.1551, 32.7160),
        City("luxor", "الأقصر", "Luxor", 25.6872, 32.6396),
        City("aswan", "أسوان", "Aswan", 24.0889, 32.8998),
        City("hurghada", "الغردقة", "Hurghada", 27.2579, 33.8116),
        City("makkah", "مكة المكرمة", "Makkah", 21.3891, 39.8579),
        City("madinah", "المدينة المنورة", "Madinah", 24.5247, 39.5692),
    )

    fun byId(id: String?): City? = if (id == null) null else all.firstOrNull { it.id == id }
}
