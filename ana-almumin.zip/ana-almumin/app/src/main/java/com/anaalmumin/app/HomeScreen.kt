package com.anaalmumin.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(prefs: AppPrefs, lang: Lang, modifier: Modifier = Modifier) {
    val s = LocalStrings.current
    val context = LocalContext.current

    var cityId by remember { mutableStateOf(prefs.cityId) }
    var gpsLat by remember { mutableStateOf(prefs.lat) }
    var gpsLon by remember { mutableStateOf(prefs.lon) }
    var showPicker by remember { mutableStateOf(false) }
    var locFailed by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(30_000L)
        }
    }

    val applyGps: (Double, Double) -> Unit = { la, lo ->
        prefs.cityId = null
        prefs.lat = la
        prefs.lon = lo
        cityId = null
        gpsLat = la
        gpsLon = lo
        locFailed = false
    }
    val useGps: () -> Unit = {
        fetchLocation(
            context,
            onResult = { la, lo -> applyGps(la, lo) },
            onFail = { locFailed = true },
        )
    }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) useGps() else locFailed = true
    }
    val requestGps: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) useGps() else permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    val city = Cities.byId(cityId)
    val la = gpsLat
    val lo = gpsLon
    val coords: Pair<Double, Double>? = when {
        city != null -> city.lat to city.lon
        la != null && lo != null -> la to lo
        else -> null
    }
    val label = when {
        city != null -> city.name(lang)
        coords != null -> s.myLocation
        else -> ""
    }

    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        if (coords == null) {
            NoLocationCard(
                failed = locFailed,
                onUseLocation = requestGps,
                onChooseCity = { showPicker = true },
            )
        } else {
            val snap = remember(coords, now) {
                PrayerCalc.snapshot(coords.first, coords.second, Date(now))
            }
            PrayerCard(
                snap = snap,
                label = label,
                lang = lang,
                onChange = { showPicker = true },
            )
            if (locFailed) {
                Spacer(Modifier.height(8.dp))
                Text(s.locationFailed, color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (showPicker) {
        CityPicker(
            lang = lang,
            onDismiss = { showPicker = false },
            onGps = {
                showPicker = false
                requestGps()
            },
            onCity = { c ->
                prefs.cityId = c.id
                cityId = c.id
                locFailed = false
                showPicker = false
            },
        )
    }
}

@Composable
private fun NoLocationCard(
    failed: Boolean,
    onUseLocation: () -> Unit,
    onChooseCity: () -> Unit,
) {
    val s = LocalStrings.current
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = s.setLocationPrompt,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onUseLocation, modifier = Modifier.fillMaxWidth()) {
                Text(s.useMyLocation)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onChooseCity, modifier = Modifier.fillMaxWidth()) {
                Text(s.chooseCity)
            }
            if (failed) {
                Spacer(Modifier.height(8.dp))
                Text(s.locationFailed, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun PrayerCard(
    snap: Snapshot,
    label: String,
    lang: Lang,
    onChange: () -> Unit,
) {
    val s = LocalStrings.current
    val locale = if (lang == Lang.AR) Locale("ar") else Locale.ENGLISH
    val timeFmt = remember(locale) { SimpleDateFormat("h:mm", locale) }
    val periodFmt = remember(locale) { SimpleDateFormat("a", locale) }

    Card(
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            CardBackground(snap.current)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(label, color = Color.White, style = MaterialTheme.typography.titleMedium)
                    TextButton(onClick = onChange) {
                        Text(s.change, color = Brand.Gold)
                    }
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = s.prayer(snap.current),
                        color = Color.White,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = timeFmt.format(snap.currentTime) + " " + periodFmt.format(snap.currentTime),
                        color = Color.White,
                        fontSize = 28.sp,
                    )
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    snap.today.forEach { (prayer, time) ->
                        val isCurrent = prayer == snap.current
                        val textColor = if (isCurrent) Color(0xFF2A2005) else Color.White
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 2.dp)
                                .background(
                                    if (isCurrent) Brand.Gold else Color.Transparent,
                                    RoundedCornerShape(12.dp),
                                )
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = s.prayer(prayer),
                                color = textColor,
                                fontSize = 12.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            )
                            Text(text = timeFmt.format(time), color = textColor, fontSize = 13.sp)
                            Text(text = periodFmt.format(time), color = textColor, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

// خلفية البطاقة حسب الصلاة الحالية. الصور تُضاف لاحقًا في res/drawable-nodpi بهذه الأسماء:
// bg_nabawi (الفجر والشروق)، bg_azhar (الظهر والعصر)، bg_fatah_alalim (المغرب والعشاء).
// إن لم تُوجد الصورة تظهر خلفية خضراء متدرجة.
@Composable
private fun CardBackground(prayer: Prayer) {
    val context = LocalContext.current
    val name = when (prayer) {
        Prayer.FAJR, Prayer.SUNRISE -> "bg_nabawi"
        Prayer.DHUHR, Prayer.ASR -> "bg_azhar"
        Prayer.MAGHRIB, Prayer.ISHA -> "bg_fatah_alalim"
    }
    val resId = remember(name) {
        context.resources.getIdentifier(name, "drawable", context.packageName)
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Brand.Emerald, Brand.DeepEmerald))),
    )
    if (resId != 0) {
        Image(
            painter = painterResource(resId),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
    }
    // طبقة شفافة لتحسين وضوح النص.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f)),
    )
}

@Composable
private fun CityPicker(
    lang: Lang,
    onDismiss: () -> Unit,
    onGps: () -> Unit,
    onCity: (City) -> Unit,
) {
    val s = LocalStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.chooseCity) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                item {
                    TextButton(onClick = onGps, modifier = Modifier.fillMaxWidth()) {
                        Text(s.useMyLocation)
                    }
                }
                items(Cities.all) { c ->
                    TextButton(onClick = { onCity(c) }, modifier = Modifier.fillMaxWidth()) {
                        Text(c.name(lang))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(s.cancel) }
        },
    )
}
