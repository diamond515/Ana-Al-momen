package com.anaalmumin.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class RepeatMode { OFF, SURAH, AYAH, AYAH_RANGE }

enum class PlayError { OFFLINE, FAILED }

object PlayerController {
    private var appContext: Context? = null
    private var prefs: AppPrefs? = null
    private var mp: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    var reader by mutableStateOf<Reader?>(null)
        private set
    var surah by mutableIntStateOf(0)
        private set
    var queue by mutableStateOf<List<Int>>(emptyList())
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var isPreparing by mutableStateOf(false)
        private set
    var positionMs by mutableIntStateOf(0)
        private set
    var durationMs by mutableIntStateOf(0)
        private set
    var repeat by mutableStateOf(RepeatMode.OFF)
        private set
    var error by mutableStateOf<PlayError?>(null)

    private val ticker = object : Runnable {
        override fun run() {
            val m = mp
            if (m != null && isPlaying) {
                try {
                    positionMs = m.currentPosition
                } catch (e: IllegalStateException) {
                    // المشغل غير جاهز.
                }
                handler.postDelayed(this, 500L)
            }
        }
    }

    fun init(context: Context, p: AppPrefs) {
        appContext = context.applicationContext
        prefs = p
    }

    fun lastSurahFor(r: Reader): Int = prefs?.lastSurah(r.id) ?: 1

    private fun isOnline(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun play(r: Reader, surahNumber: Int, newQueue: List<Int>) {
        val ctx = appContext ?: return
        if (!isOnline(ctx)) {
            error = PlayError.OFFLINE
            return
        }
        release()
        reader = r
        surah = surahNumber
        queue = newQueue
        positionMs = 0
        durationMs = 0
        isPreparing = true
        isPlaying = false
        prefs?.setLastSurah(r.id, surahNumber)

        val m = MediaPlayer()
        mp = m
        try {
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build(),
            )
            m.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(r.url(surahNumber))
            m.isLooping = repeat == RepeatMode.SURAH
            m.setOnPreparedListener { p ->
                if (mp === p) {
                    durationMs = p.duration
                    p.start()
                    isPlaying = true
                    isPreparing = false
                    handler.removeCallbacks(ticker)
                    handler.post(ticker)
                }
            }
            m.setOnCompletionListener { p ->
                if (mp === p) onCompleted()
            }
            m.setOnErrorListener { p, _, _ ->
                if (mp === p) {
                    error = PlayError.FAILED
                    isPlaying = false
                    isPreparing = false
                }
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            error = PlayError.FAILED
            isPreparing = false
        }
    }

    private fun onCompleted() {
        val r = reader
        val idx = queue.indexOf(surah)
        if (r != null && idx >= 0 && idx < queue.size - 1) {
            play(r, queue[idx + 1], queue)
        } else {
            isPlaying = false
            positionMs = 0
            handler.removeCallbacks(ticker)
        }
    }

    fun toggle() {
        val m = mp ?: return
        try {
            if (isPlaying) {
                m.pause()
                isPlaying = false
                handler.removeCallbacks(ticker)
            } else if (!isPreparing) {
                m.start()
                isPlaying = true
                handler.removeCallbacks(ticker)
                handler.post(ticker)
            }
        } catch (e: IllegalStateException) {
            error = PlayError.FAILED
        }
    }

    fun next() {
        val r = reader ?: return
        val idx = queue.indexOf(surah)
        if (idx >= 0 && idx < queue.size - 1) play(r, queue[idx + 1], queue)
    }

    fun previous() {
        val r = reader ?: return
        if (positionMs > 3000) {
            seekTo(0)
            return
        }
        val idx = queue.indexOf(surah)
        if (idx > 0) play(r, queue[idx - 1], queue)
    }

    fun seekTo(ms: Int) {
        try {
            mp?.seekTo(ms)
            positionMs = ms
        } catch (e: IllegalStateException) {
            // تجاهل.
        }
    }

    fun setRepeat(mode: RepeatMode) {
        // آية ومجموعة آيات تحتاجان تسجيلات آية بآية؛ لم تُفعّلا بعد.
        if (mode != RepeatMode.OFF && mode != RepeatMode.SURAH) return
        repeat = mode
        try {
            mp?.isLooping = mode == RepeatMode.SURAH
        } catch (e: IllegalStateException) {
            // تجاهل.
        }
    }

    private fun release() {
        handler.removeCallbacks(ticker)
        try {
            mp?.release()
        } catch (e: Exception) {
            // تجاهل.
        }
        mp = null
        isPlaying = false
    }
}
