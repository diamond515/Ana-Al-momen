package com.anaalmumin.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Brand {
    val Emerald = Color(0xFF0B7A5C)
    val DeepEmerald = Color(0xFF064E3B)
    val Gold = Color(0xFFD8B45A)
    val Ivory = Color(0xFFF4F1E8)
    val Red = Color(0xFFB03030)
    val Success = Color(0xFF1A6B43)
}

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(
            primary = Brand.Emerald,
            onPrimary = Color.White,
            secondary = Brand.Gold,
            onSecondary = Color.Black,
            background = Color(0xFF0A1411),
            onBackground = Brand.Ivory,
            surface = Color(0xFF10201A),
            onSurface = Brand.Ivory,
            primaryContainer = Brand.DeepEmerald,
            onPrimaryContainer = Brand.Ivory,
            error = Brand.Red,
        )
    } else {
        lightColorScheme(
            primary = Brand.Emerald,
            onPrimary = Color.White,
            secondary = Brand.Gold,
            onSecondary = Color(0xFF3A2E0A),
            background = Brand.Ivory,
            onBackground = Color(0xFF1B1B1B),
            surface = Brand.Ivory,
            onSurface = Color(0xFF1B1B1B),
            primaryContainer = Color(0xFFD7EBE3),
            onPrimaryContainer = Brand.DeepEmerald,
            error = Brand.Red,
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
