package com.anaalmumin.app

object Config {
    // رقم واتساب للتواصل (بصيغة دولية بدون +). غير محدد في الوثيقة؛ اتركه فارغًا حتى تحدده.
    const val WHATSAPP_NUMBER = ""
}
