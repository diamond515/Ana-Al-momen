package com.anaalmumin.app

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.util.Date

enum class Prayer { FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA }

data class Snapshot(
    val current: Prayer,
    val currentTime: Date,
    val today: List<Pair<Prayer, Date>>,
)

object PrayerCalc {
    // الطريقة: الهيئة المصرية العامة للمساحة، ثابتة حسب قرارك.
    private fun timesFor(lat: Double, lon: Double, date: Date): List<Pair<Prayer, Date>> {
        val params = CalculationMethod.EGYPTIAN.parameters
        val t = PrayerTimes(Coordinates(lat, lon), DateComponents.from(date), params)
        return listOf(
            Prayer.FAJR to t.fajr,
            Prayer.SUNRISE to t.sunrise,
            Prayer.DHUHR to t.dhuhr,
            Prayer.ASR to t.asr,
            Prayer.MAGHRIB to t.maghrib,
            Prayer.ISHA to t.isha,
        )
    }

    fun snapshot(lat: Double, lon: Double, now: Date): Snapshot {
        val today = timesFor(lat, lon, now)
        val passed = today.lastOrNull { it.second.time <= now.time }
        if (passed != null) return Snapshot(passed.first, passed.second, today)
        // قبل الفجر: الصلاة الحالية هي عشاء اليوم السابق.
        val yesterday = timesFor(lat, lon, Date(now.time - 24L * 60L * 60L * 1000L))
        return Snapshot(Prayer.ISHA, yesterday.last().second, today)
    }
}
