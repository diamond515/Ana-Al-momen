package com.anaalmumin.app

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class Page { MAIN, SETTINGS, FAVORITES, DOWNLOADS, SOURCES, ABOUT }

@Composable
fun App(prefs: AppPrefs) {
    var lang by remember { mutableStateOf(prefs.lang) }
    var theme by remember { mutableStateOf(prefs.theme) }

    val dark = when (theme) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val direction = if (lang == Lang.AR) LayoutDirection.Rtl else LayoutDirection.Ltr

    AppTheme(dark = dark) {
        CompositionLocalProvider(
            LocalLayoutDirection provides direction,
            LocalStrings provides Strings(lang),
        ) {
            var showSplash by rememberSaveable { mutableStateOf(true) }
            if (showSplash) {
                SplashScreen { showSplash = false }
            } else {
                Root(
                    lang = lang,
                    theme = theme,
                    onLang = {
                        lang = it
                        prefs.lang = it
                    },
                    onTheme = {
                        theme = it
                        prefs.theme = it
                    },
                )
            }
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        // تفاصيل الشعار والحركة مؤجلة حسب الوثيقة؛ هذه شاشة مؤقتة.
        delay(1500)
        onDone()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.DeepEmerald),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = LocalStrings.current.appName,
            color = Brand.Gold,
            fontSize = 36.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
