package com.anaalmumin.app

import androidx.compose.runtime.staticCompositionLocalOf

class Strings(private val lang: Lang) {
    private fun t(ar: String, en: String): String = if (lang == Lang.AR) ar else en

    val appName: String get() = "أنا المؤمن"

    val tabQuran: String get() = t("القرآن", "Quran")
    val tabSearch: String get() = t("البحث القرآني", "Quran Search")
    val tabHome: String get() = t("الرئيسية", "Home")
    val tabAzkar: String get() = t("الأذكار", "Adhkar")
    val tabStories: String get() = t("القصص", "Stories")

    val settings: String get() = t("الإعدادات", "Settings")
    val favorites: String get() = t("المفضلة", "Favorites")
    val downloads: String get() = t("التنزيلات", "Downloads")
    val sources: String get() = t("المصادر والتراخيص", "Sources & Licenses")
    val about: String get() = t("عن التطبيق", "About")
    val whatsapp: String get() = t("التواصل عبر واتساب", "Contact via WhatsApp")

    val language: String get() = t("اللغة", "Language")
    val arabic: String get() = "العربية"
    val english: String get() = "English"
    val appearance: String get() = t("المظهر", "Appearance")
    val themeLight: String get() = t("فاتح", "Light")
    val themeDark: String get() = t("داكن", "Dark")
    val themeSystem: String get() = t("حسب الجهاز", "System default")

    val exitHint: String get() = t("أنت على وشك مغادرة التطبيق", "You are about to leave the app")
    val back: String get() = t("رجوع", "Back")
    val menu: String get() = t("القائمة", "Menu")
}

val LocalStrings = staticCompositionLocalOf { Strings(Lang.AR) }
