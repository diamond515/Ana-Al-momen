package com.anaalmumin.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val allSurahs: List<Int> = (1..SurahNames.COUNT).toList()

private fun formatTime(ms: Int): String {
    val total = ms / 1000
    return String.format(Locale.ROOT, "%d:%02d", total / 60, total % 60)
}

// ---------- إطار الشاشات الفرعية ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubScaffold(
    title: String,
    onBack: () -> Unit,
    onOpenPlayer: (() -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit,
) {
    val s = LocalStrings.current
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                },
            )
        },
        bottomBar = {
            if (onOpenPlayer != null && PlayerController.reader != null) {
                MiniPlayer(onOpenPlayer)
            }
        },
        content = content,
    )
}

@Composable
fun MiniPlayer(onOpen: () -> Unit) {
    val s = LocalStrings.current
    val r = PlayerController.reader
    if (r != null) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpen),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = SurahNames.name(PlayerController.surah, s.lang),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(text = r.name(s.lang), style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { PlayerController.toggle() }) {
                    if (PlayerController.isPreparing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(
                            imageVector = if (PlayerController.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = null,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReaderAvatar(name: String, size: Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        // الصورة الحقيقية للقارئ تُضاف لاحقًا بعد التحقق من ترخيصها.
        Text(
            text = name.take(1),
            fontSize = (size.value / 2.2f).sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
    }
}

// ---------- شاشة القرآن (التبويب) ----------

@Composable
fun QuranHomeScreen(onListen: () -> Unit, modifier: Modifier = Modifier) {
    val s = LocalStrings.current
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        QuranOption(Icons.Filled.Headphones, s.quranListen, onListen)
        QuranOption(Icons.Filled.TextFields, s.quranText) {}
        QuranOption(Icons.Filled.MenuBook, s.quranMushaf) {}
    }
}

@Composable
private fun QuranOption(icon: ImageVector, title: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(24.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp),
            )
            Spacer(Modifier.width(16.dp))
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
    }
}

// ---------- مكتبة القراء ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadersScreen(
    onBack: () -> Unit,
    onOpenReader: (String) -> Unit,
    onOpenPlayer: () -> Unit,
) {
    val s = LocalStrings.current
    var onlyFav by remember { mutableStateOf(false) }
    var riwaya by remember { mutableStateOf<String?>(null) }

    val riwayat = Readers.all.map { it.riwayaAr }.distinct()
    val list = Readers.all.filter {
        (!onlyFav || it.id in Favs.readerIds) && (riwaya == null || it.riwayaAr == riwaya)
    }

    SubScaffold(title = s.readersTitle, onBack = onBack, onOpenPlayer = onOpenPlayer) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(
                    selected = onlyFav,
                    onClick = { onlyFav = !onlyFav },
                    label = { Text(s.favoritesFilter) },
                )
                riwayat.forEach { key ->
                    val label = Readers.all.first { it.riwayaAr == key }.riwaya(s.lang)
                    FilterChip(
                        selected = riwaya == key,
                        onClick = { riwaya = if (riwaya == key) null else key },
                        label = { Text(label) },
                    )
                }
            }
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(list) { r ->
                    ReaderRow(r, onOpen = { onOpenReader(r.id) })
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun ReaderRow(r: Reader, onOpen: () -> Unit) {
    val s = LocalStrings.current
    val isFav = r.id in Favs.readerIds
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ReaderAvatar(r.name(s.lang), 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(r.name(s.lang), style = MaterialTheme.typography.titleMedium)
            Text(r.riwaya(s.lang), style = MaterialTheme.typography.bodySmall)
        }
        IconButton(onClick = { Favs.toggleReader(r.id) }) {
            Icon(
                imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = null,
                tint = if (isFav) Brand.Gold else MaterialTheme.colorScheme.onSurface,
            )
        }
        IconButton(onClick = {
            // تشغيل سريع: آخر سورة سمعها المستخدم بصوت هذا القارئ، وإلا الفاتحة.
            PlayerController.play(r, PlayerController.lastSurahFor(r), allSurahs)
        }) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

// ---------- صفحة القارئ ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    readerId: String,
    onBack: () -> Unit,
    onOpenPlayer: () -> Unit,
) {
    val s = LocalStrings.current
    val r = Readers.byId(readerId)
    if (r == null) {
        SubScaffold(title = s.readersTitle, onBack = onBack) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding))
        }
        return
    }
    val isFav = r.id in Favs.readerIds

    SubScaffold(title = r.name(s.lang), onBack = onBack, onOpenPlayer = onOpenPlayer) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    ReaderAvatar(r.name(s.lang), 160.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(r.name(s.lang), style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    FilterChip(
                        selected = true,
                        onClick = {},
                        label = { Text(r.riwaya(s.lang)) },
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            PlayerController.play(r, PlayerController.lastSurahFor(r), allSurahs)
                            onOpenPlayer()
                        }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text(s.play)
                        }
                        OutlinedButton(onClick = {
                            PlayerController.play(r, 1, allSurahs)
                            onOpenPlayer()
                        }) {
                            Text(s.playAll)
                        }
                        IconButton(onClick = { Favs.toggleReader(r.id) }) {
                            Icon(
                                imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = null,
                                tint = if (isFav) Brand.Gold else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(s.noBio, style = MaterialTheme.typography.bodyMedium)
                }
                HorizontalDivider()
                Text(
                    text = s.recitations,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(16.dp),
                )
            }
            items(allSurahs) { n ->
                val active = PlayerController.reader?.id == r.id && PlayerController.surah == n
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            PlayerController.play(r, n, allSurahs)
                            onOpenPlayer()
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = n.toString(),
                        modifier = Modifier.width(40.dp),
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = SurahNames.name(n, s.lang),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = if (active && PlayerController.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
    }
}

// ---------- مشغل القرآن ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(onBack: () -> Unit) {
    val s = LocalStrings.current
    val reader = PlayerController.reader
    var showRepeat by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    SubScaffold(title = reader?.name(s.lang) ?: s.readersTitle, onBack = onBack) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            ReaderAvatar(reader?.name(s.lang) ?: "", 180.dp)
            Spacer(Modifier.height(20.dp))
            Text(
                text = if (PlayerController.surah > 0) SurahNames.name(PlayerController.surah, s.lang) else "",
                style = MaterialTheme.typography.headlineLarge,
            )
            Text(
                text = reader?.riwaya(s.lang) ?: "",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(32.dp))

            // أدوات التحكم لا تنعكس مع RTL (عرف المشغلات).
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    val duration = PlayerController.durationMs.coerceAtLeast(1)
                    val shown = if (dragging) dragValue else PlayerController.positionMs.toFloat()
                    Slider(
                        value = shown.coerceIn(0f, duration.toFloat()),
                        onValueChange = {
                            dragging = true
                            dragValue = it
                        },
                        onValueChangeFinished = {
                            PlayerController.seekTo(dragValue.toInt())
                            dragging = false
                        },
                        valueRange = 0f..duration.toFloat(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(formatTime(shown.toInt()), style = MaterialTheme.typography.bodySmall)
                        Text(formatTime(PlayerController.durationMs), style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { showRepeat = true }) {
                            val on = PlayerController.repeat != RepeatMode.OFF
                            Icon(
                                imageVector = if (PlayerController.repeat == RepeatMode.SURAH) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                                contentDescription = s.repeatTitle,
                                tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        IconButton(onClick = { PlayerController.previous() }) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = null, modifier = Modifier.size(36.dp))
                        }
                        FilledIconButton(
                            onClick = { PlayerController.toggle() },
                            modifier = Modifier.size(72.dp),
                        ) {
                            if (PlayerController.isPreparing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(32.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 3.dp,
                                )
                            } else {
                                Icon(
                                    imageVector = if (PlayerController.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp),
                                )
                            }
                        }
                        IconButton(onClick = { PlayerController.next() }) {
                            Icon(Icons.Filled.SkipNext, contentDescription = null, modifier = Modifier.size(36.dp))
                        }
                        // مساحة لموازنة زر التكرار.
                        Spacer(Modifier.size(48.dp))
                    }
                }
            }
        }
    }

    if (showRepeat) {
        ModalBottomSheet(onDismissRequest = { showRepeat = false }) {
            Column(modifier = Modifier.padding(bottom = 32.dp)) {
                Text(
                    text = s.repeatTitle,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(16.dp),
                )
                RepeatRow(s.repeatOff, PlayerController.repeat == RepeatMode.OFF, true) {
                    PlayerController.setRepeat(RepeatMode.OFF)
                    showRepeat = false
                }
                RepeatRow(s.repeatSurah, PlayerController.repeat == RepeatMode.SURAH, true) {
                    PlayerController.setRepeat(RepeatMode.SURAH)
                    showRepeat = false
                }
                // آية ومجموعة آيات: تحتاجان تسجيلات آية بآية، تُفعَّلان في مرحلة لاحقة.
                RepeatRow(s.repeatAyah, false, false) {}
                RepeatRow(s.repeatAyahs, false, false) {}
            }
        }
    }
}

@Composable
private fun RepeatRow(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick, enabled = enabled)
        Text(label, modifier = Modifier.padding(horizontal = 8.dp))
    }
}
