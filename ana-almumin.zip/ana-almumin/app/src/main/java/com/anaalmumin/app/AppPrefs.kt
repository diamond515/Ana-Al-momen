package com.anaalmumin.app

import android.content.Context

enum class Lang(val code: String) { AR("ar"), EN("en") }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var lang: Lang
        get() = if (sp.getString("lang", "ar") == "en") Lang.EN else Lang.AR
        set(value) {
            sp.edit().putString("lang", value.code).apply()
        }

    var theme: ThemeMode
        get() = when (sp.getString("theme", "system")) {
            "light" -> ThemeMode.LIGHT
            "dark" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
        set(value) {
            sp.edit().putString("theme", value.name.lowercase()).apply()
        }
}
