package com.anaalmumin.app

import android.content.Context

enum class Lang(val code: String) { AR("ar"), EN("en") }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var lang: Lang
        get() = if (sp.getString("lang", "ar") == "en") Lang.EN else Lang.AR
        set(value) {
            sp.edit().putString("lang", value.code).apply()
        }

    var cityId: String?
        get() = sp.getString("city_id", null)
        set(value) {
            if (value == null) sp.edit().remove("city_id").apply()
            else sp.edit().putString("city_id", value).apply()
        }

    var lat: Double?
        get() = sp.getString("lat", null)?.toDoubleOrNull()
        set(value) {
            if (value == null) sp.edit().remove("lat").apply()
            else sp.edit().putString("lat", value.toString()).apply()
        }

    var lon: Double?
        get() = sp.getString("lon", null)?.toDoubleOrNull()
        set(value) {
            if (value == null) sp.edit().remove("lon").apply()
            else sp.edit().putString("lon", value.toString()).apply()
        }

    var theme: ThemeMode
        get() = when (sp.getString("theme", "system")) {
            "light" -> ThemeMode.LIGHT
            "dark" -> ThemeMode.DARK
            else -> ThemeMode.SYSTEM
        }
        set(value) {
            sp.edit().putString("theme", value.name.lowercase()).apply()
        }
}
