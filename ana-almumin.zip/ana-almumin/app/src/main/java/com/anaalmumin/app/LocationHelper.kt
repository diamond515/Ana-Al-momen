package com.anaalmumin.app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
fun fetchLocation(
    context: Context,
    onResult: (Double, Double) -> Unit,
    onFail: () -> Unit,
) {
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    if (lm == null) {
        onFail()
        return
    }
    try {
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (p in providers) {
            val l = lm.getLastKnownLocation(p)
            val current = best
            if (l != null && (current == null || l.time > current.time)) best = l
        }
        val found = best
        if (found != null) {
            onResult(found.latitude, found.longitude)
            return
        }
        val provider = when {
            providers.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            providers.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            onFail()
            return
        }
        lm.requestSingleUpdate(
            provider,
            object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    onResult(location.latitude, location.longitude)
                }

                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            },
            Looper.getMainLooper(),
        )
    } catch (e: Exception) {
        onFail()
    }
}
